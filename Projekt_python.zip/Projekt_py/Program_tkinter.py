# slovarji pridobljeni z datoteko Pridobivanje_podatkov
decki_rojstva = {2005: ('Rojstva-9.376', 'Živorojeni-9.323', 'Mrtvorojeni-53'),
                 2006: ('Rojstva-9.814', 'Živorojeni-9.772', 'Mrtvorojeni-42'),
                 2007: ('Rojstva-10.213', 'Živorojeni-10.166', 'Mrtvorojeni-47'),
                 2008: ('Rojstva-11.173', 'Živorojeni-11.107', 'Mrtvorojeni-66'),
                 2009: ('Rojstva-11.281', 'Živorojeni-11.214', 'Mrtvorojeni-67'),
                 2010: ('Rojstva-11.503', 'Živorojeni-11.454', 'Mrtvorojeni-49'),
                 2011: ('Rojstva-11.196', 'Živorojeni-11.140', 'Mrtvorojeni-56'),
                 2012: ('Rojstva-11.253', 'Živorojeni-11.201', 'Mrtvorojeni-52'),
                 2013: ('Rojstva-10.689', 'Živorojeni-10.642', 'Mrtvorojeni-47'),
                 2014: ('Rojstva-10.773', 'Živorojeni-10.720', 'Mrtvorojeni-53'),
                 2015: ('Rojstva-10.427', 'Živorojeni-10.368', 'Mrtvorojeni-59'),
                 2016: ('Rojstva-10.246', 'Živorojeni-10.185', 'Mrtvorojeni-61'),
                 2017: ('Rojstva-10.339', 'Živorojeni-10.282', 'Mrtvorojeni-57'),
                 2018: ('Rojstva-10.031', 'Živorojeni-9.984', 'Mrtvorojeni-47')}
deklice_rojstva = {2005: ('Rojstva-8.823', 'Živorojene-8.765', 'Mrtvorojene-58'),
                   2006: ('Rojstva-9.215', 'Živorojene-9.175', 'Mrtvorojene-40'),
                   2007: ('Rojstva-9.702', 'Živorojene-9.648', 'Mrtvorojene-54'),
                   2008: ('Rojstva-10.693', 'Živorojene-10.650', 'Mrtvorojene-43'),
                   2009: ('Rojstva-10.482', 'Živorojene-10.430', 'Mrtvorojene-52'),
                   2010: ('Rojstva-10.793', 'Živorojene-10.742', 'Mrtvorojene-51'),
                   2011: ('Rojstva-10.650', 'Živorojene-10.594', 'Mrtvorojene-56'),
                   2012: ('Rojstva-10.536', 'Živorojene-10.493', 'Mrtvorojene-43'),
                   2013: ('Rojstva-10.186', 'Živorojene-10.135', 'Mrtvorojene-51'),
                   2014: ('Rojstva-10.084', 'Živorojene-10.048', 'Mrtvorojene-36'),
                   2015: ('Rojstva-9.853', 'Živorojene-9.813', 'Mrtvorojene-40'),
                   2016: ('Rojstva-9.837', 'Živorojene-9.800', 'Mrtvorojene-37'),
                   2017: ('Rojstva-9.608', 'Živorojene-9.566', 'Mrtvorojene-42'),
                   2018: ('Rojstva-9.298', 'Živorojene-9.261', 'Mrtvorojene-37')}



moski_pricakovana_leta = {'2005': ['Ob rojstvu: 73,9', '50 let: 26,8', '65 let: 15,2'],
                '2006': ['Ob rojstvu: 74,5', '50 let: 27,2', '65 let: 15,8'],
                '2007': ['Ob rojstvu: 74,6', '50 let: 27,4', '65 let: 15,9'],
                '2008': ['Ob rojstvu: 75,5', '50 let: 28,0', '65 let: 16,4'],
                '2009': ['Ob rojstvu: 75,9', '50 let: 28,2', '65 let: 16,4'],
                '2010': ['Ob rojstvu: 76,4', '50 let: 28,5', '65 let: 16,8'],
                '2011': ['Ob rojstvu: 76,8', '50 let: 28,9', '65 let: 16,9'],
                '2012': ['Ob rojstvu: 77,1', '50 let: 29,0', '65 let: 17,1'],
                '2013': ['Ob rojstvu: 77,2', '50 let: 29,2', '65 let: 17,2'],
                '2014': ['Ob rojstvu: 78,2', '50 let: 29,9', '65 let: 17,7'],
                '2015': ['Ob rojstvu: 77,8', '50 let: 29,7', '65 let: 17,6'],
                '2016': ['Ob rojstvu: 78,2', '50 let: 30,0', '65 let: 17,9'],
                '2017': ['Ob rojstvu: 78,2', '50 let: 29,8', '65 let: 17,6'],
                '2018': ['Ob rojstvu: 78,5', '50 let: 30,2', '65 let: 17,8']}
zenske_pricakovana_leta = {'2005': ['Ob rojstvu: 80,9', '50 let: 32,4', '65 let: 19,3'],
                         '2006': ['Ob rojstvu: 82,0', '50 let: 33,2', '65 let: 20,0'],
                         '2007': ['Ob rojstvu: 82,0', '50 let: 33,4', '65 let: 20,2'],
                         '2008': ['Ob rojstvu: 82,6', '50 let: 33,8', '65 let: 20,5'],
                         '2009': ['Ob rojstvu: 82,7', '50 let: 33,8', '65 let: 20,5'],
                         '2010': ['Ob rojstvu: 83,1', '50 let: 34,4', '65 let: 21,0'],
                         '2011': ['Ob rojstvu: 83,3', '50 let: 34,5', '65 let: 21,1'],
                         '2012': ['Ob rojstvu: 83,3', '50 let: 34,3', '65 let: 21,1'],
                         '2013': ['Ob rojstvu: 83,6', '50 let: 34,8', '65 let: 21,4'],
                         '2014': ['Ob rojstvu: 84,1', '50 let: 35,1', '65 let: 21,6'],
                         '2015': ['Ob rojstvu: 83,9', '50 let: 34,9', '65 let: 21,4'],
                         '2016': ['Ob rojstvu: 84,3', '50 let: 35,3', '65 let: 21,8'],
                         '2017': ['Ob rojstvu: 84,0', '50 let: 35,1', '65 let: 21,7'],
                         '2018': ['Ob rojstvu: 84,4', '50 let: 35,2', '65 let: 21,8']}


from tkinter import *

# uporabnik izbere željeni spol, za katerega ga zanimajo podatki o zdravju
class Spol:
    def __init__(self, master):
        self.master = master
        self.frame = Frame(self.master)
        self.button1 = Button(self.frame, text = 'moški', width = 25, command = self.novo_okno_m)
        self.frame2 = Frame(self.master)
        self.button2 = Button(self.frame2, text = 'ženske', width = 25, command = self.novo_okno_z)
        self.button1.pack()
        self.frame.pack()
        self.button2.pack()
        self.frame2.pack()
    
    # gumb za moške, kliče okenček s podatki za moške
    def novo_okno_m(self):
        self.okno = Toplevel(self.master)
        self.app = Moski(self.okno)
    # gumb za ženske, kliče okenček s podatki za ženske
    def novo_okno_z(self):
        self.okno = Toplevel(self.master)
        self.app = Zenske(self.okno)

class Moski(Spol):
    # uporabnik klikne željeno temo
    def __init__(self, master):
        self.master = master
        self.frame = Frame(self.master)
        self.gumb1 = Button(self.frame, text = 'Pričakovana leta življenja', width = 25, command = self.novo_okno2_m)
        self.frame2 = Frame(self.master)
        self.gumb2 = Button(self.frame2, text = 'Porodi', width = 25, command = self.novo_okno3_m)
        self.frame5 = Frame(self.master)
        self.gumb5 = Button(self.frame2, text = 'Spolne bolezni', width = 25, command = self.novo_okno5_m)
        self.frame6 = Frame(self.master)
        self.gumb6 = Button(self.frame6, text = 'Poškodbe pri delu', width = 25, command = self.novo_okno4_m)
        self.gumb1.pack()
        self.frame.pack()
        self.gumb2.pack()
        self.frame2.pack()
        self.gumb5.pack()
        self.frame5.pack()
        self.gumb6.pack()
        self.frame6.pack()
        
    def novo_okno2_m(self):
        self.okno = Toplevel(self.master)
        self.app = Pricakovana_leta_M(self.okno)
    def novo_okno3_m(self):
        self.okno = Toplevel(self.master)
        self.app = Porodi_M(self.okno)
    def novo_okno4_m(self):
        self.okno = Toplevel(self.master)
        self.app = Poskodbe_M(self.okno)
    def novo_okno5_m(self):
        self.okno = Toplevel(self.master)
        self.app = Bolezni_M(self.okno)
    
class Zenske(Spol):
    # uporabnik klikne željeno temo
    def __init__(self, master):
        self.master = master
        self.frame = Frame(self.master)
        self.gumb1 = Button(self.frame, text = 'Pričakovana leta življenja', width = 25, command = self.novo_okno2_z)
        self.frame2 = Frame(self.master)
        self.gumb2 = Button(self.frame2, text = 'Porodi', width = 25, command = self.novo_okno3_z)
        self.frame4 = Frame(self.master)
        self.gumb4 = Button(self.frame, text = 'Fetalne smrti', width = 25, command = self.novo_okno4_z)
        self.frame5 = Frame(self.master)
        self.gumb5 = Button(self.frame2, text = 'Spolne bolezni', width = 25, command = self.novo_okno6_z)
        self.frame6 = Frame(self.master)
        self.gumb6 = Button(self.frame6, text = 'Poškodbe pri delu', width = 25, command = self.novo_okno5_z)
        self.gumb1.pack()
        self.frame.pack()
        self.gumb2.pack()
        self.frame2.pack()
        self.gumb4.pack()
        self.frame4.pack()
        self.gumb5.pack()
        self.frame5.pack()
        self.gumb6.pack()
        self.frame6.pack()
        
    def novo_okno2_z(self):
        self.okno = Toplevel(self.master)
        self.app = Pricakovana_leta_Z(self.okno)
    def novo_okno3_z(self):
        self.okno = Toplevel(self.master)
        self.app = Porodi_Z(self.okno)
    def novo_okno4_z(self):
        self.okno = Toplevel(self.master)
        self.app = Fetalne_smrti(self.okno)
    def novo_okno5_z(self):
        self.okno = Toplevel(self.master)
        self.app = Poskodbe_Z(self.okno)
    def novo_okno6_z(self):
        self.okno = Toplevel(self.master)
        self.app = Bolezni_Z(self.okno)


def spolne_bolezni_z(leto):
    '''Iz datoteke z ustreznimi podatki za ženske vrne slovar števil okuženih z različnimi boleznimi v Sloveniji v nekem letu.
        Če podatka za izbrano leto nimamo, to tudi izpiše.'''
    podatki = dict()
    with open('Bolezni_Z.txt', 'r') as datoteka:
        for vrstica in datoteka:
            tab = re.findall(r'[0-9][0-9]*', vrstica)
            for index in range(len(tab)):
                if tab[index] == leto and index%8 == 0:
                    podatki['HIV'] = tab[index+1]
                    podatki['AIDS'] = tab[index+2]
                    podatki['Zgodnji sifilis'] = tab[index+3]
                    podatki['Pozni sifilis'] = tab[index+4]
                    podatki['Neopredeljeni sifilis'] = tab[index+5]
                    podatki['Gonoreja'] = tab[index+6]
                    podatki['Klamidijska okužba'] = tab[index+7]
                    break
    return podatki


class Bolezni_Z:
    def __init__(self, master):
        vprasanje = Label(master, text = 'Vtipkajte željeno leto:')
        vprasanje.grid(row = 0, column = 0)
        self.ime = StringVar(master, value = None)
        polje_ime = Entry(master, textvariable = self.ime)
        polje_ime.grid(row = 1, column = 0)
        gumb = Button(master, text = 'Podatki:', command = self.isci_bolezni)
        gumb.grid(row = 2, column = 0)
        self.rezultat = IntVar(master, value = 0)
        polje_rezultat = Label(master, textvariable = self.rezultat)
        polje_rezultat.grid(row = 3, column = 0)
        
    def isci_bolezni(self):
        try:
            leto = self.ime.get()
            slovar = spolne_bolezni_z(leto)
            text = ''
            for kljuc, vr in slovar.items():
                text += '{}:{}'.format(kljuc, vr) + '\n'
            if slovar:
                self.rezultat.set(text)
            else: self.rezultat.set('Ni podatka za to leto.')
        except: print('Vnešeno ni število.')

def spolne_bolezni_m(leto):
    '''Iz datoteke z ustreznimi podatki za moške vrne slovar števil okuženih z različnimi boleznimi v Sloveniji v nekem letu.
        Če podatka za izbrano leto nimamo, to tudi izpiše.'''
    podatki = dict()
    with open('Bolezni_M.txt', 'r') as datoteka:
        for vrstica in datoteka:
            tab = re.findall(r'[0-9][0-9]*', vrstica)
            for index in range(len(tab)):
                if tab[index] == leto and index%8 == 0:
                    podatki['HIV'] = tab[index+1]
                    podatki['AIDS'] = tab[index+2]
                    podatki['Zgodnji sifilis'] = tab[index+3]
                    podatki['Pozni sifilis'] = tab[index+4]
                    podatki['Neopredeljeni sifilis'] = tab[index+5]
                    podatki['Gonoreja'] = tab[index+6]
                    podatki['Klamidijska okužba'] = tab[index+7]
                    break
    return podatki

class Bolezni_M:
    def __init__(self, master):
        vprasanje = Label(master, text = 'Vtipkajte željeno leto:')
        vprasanje.grid(row = 0, column = 0)
        self.ime = StringVar(master, value = None)
        polje_ime = Entry(master, textvariable = self.ime)
        polje_ime.grid(row = 1, column = 0)
        gumb = Button(master, text = 'Podatki:', command = self.isci_bolezni)
        gumb.grid(row = 2, column = 0)
        self.rezultat = IntVar(master, value = 0)
        polje_rezultat = Label(master, textvariable = self.rezultat)
        polje_rezultat.grid(row = 3, column = 0)
        
    def isci_bolezni(self):
        leto = self.ime.get()
        slovar = spolne_bolezni_m(leto)
        text = ''
        for kljuc, vr in slovar.items():
            text += '{}:{}'.format(kljuc, vr) + '\n'
        if slovar:
            self.rezultat.set(text)
        else: self.rezultat.set('Ni podatka za to leto.')


        
def poskodbe_z(leto):
    '''Vrne seznam števil prijavljenih poškodb pri delu žensk v Sloveniji za neko leto.'''
    leto = int(leto)
    slov = 0
    with open('Poskodbe_Z.txt', 'r') as dat:
        podatki = list()
        for vrstica in dat:
            if slov == 1:
                tab = re.findall(r'[1-9][0-9]*', vrstica)
                for index in range(len(tab)):
                    if int(tab[index]) == leto and (index % 2 == 0):
                        podatki.append('{}-{}'.format(kljuc, tab[index+1]))
                        slov = 0
            
            if 'Na običajnem delovnem mestu' in vrstica:
                kljuc = vrstica[:-1]
                slov = 1
            elif 'Začasno delovno mesto v isti enoti' in vrstica:
                kljuc = vrstica[:-1]
                slov = 1
            elif 'Službena pot ali delovno mesto v drugi enoti' in vrstica:
                kljuc = vrstica[:-1]
                slov = 1
            elif 'Pot na delo' in vrstica:
                kljuc = vrstica[:-1]
                slov = 1
            elif 'Pot z dela' in vrstica:
                kljuc = vrstica[:-1]
                slov = 1
    return podatki

def poskodbe_m(leto):
    '''Vrne seznam števil prijavljenih poškodb pri delu moških v Sloveniji za neko leto.'''
    leto = int(leto)
    slov = 0
    with open('Poskodbe_M.txt', 'r') as dat:
        podatki = list()
        for vrstica in dat:
            if slov == 1:
                tab = re.findall(r'[1-9][0-9]*', vrstica)
                for index in range(len(tab)):
                    if int(tab[index]) == leto and (index % 2 == 0):
                        podatki.append('{}-{}'.format(kljuc, tab[index+1]))
                        slov = 0
            
            if 'Na običajnem delovnem mestu' in vrstica:
                kljuc = vrstica[:-1]
                slov = 1
            elif 'Začasno delovno mesto v isti enoti' in vrstica:
                kljuc = vrstica[:-1]
                slov = 1
            elif 'Službena pot ali delovno mesto v drugi enoti' in vrstica:
                kljuc = vrstica[:-1]
                slov = 1
            elif 'Pot na delo' in vrstica:
                kljuc = vrstica[:-1]
                slov = 1
            elif 'Pot z dela' in vrstica:
                kljuc = vrstica[:-1]
                slov = 1
    return podatki
    
        
class Poskodbe_M:
    def __init__(self, master):
        vprasanje = Label(master, text = 'Vtipkajte željeno leto:')
        vprasanje.grid(row = 0, column = 0)
        self.ime = StringVar(master, value = None)
        polje_ime = Entry(master, textvariable = self.ime)
        polje_ime.grid(row = 1, column = 0)
        gumb = Button(master, text = 'Podatki:', command = self.isci_poskodbe)
        gumb.grid(row = 2, column = 0)
        self.rezultat = IntVar(master, value = 0)
        polje_rezultat = Label(master, textvariable = self.rezultat)
        polje_rezultat.grid(row = 3, column = 0)
        
    def isci_poskodbe(self):
        leto = self.ime.get()
        tabela = poskodbe_m(leto)
        text = ''
        for elt in tabela:
            text += elt + '\n'
        if tabela:
            self.rezultat.set(text)
        else: self.rezultat.set('Ni podatka za to leto.')

    
class Poskodbe_Z:
    def __init__(self, master):
        vprasanje = Label(master, text = 'Vtipkajte željeno leto:')
        vprasanje.grid(row = 0, column = 0)
        self.ime = StringVar(master, value = None)
        polje_ime = Entry(master, textvariable = self.ime)
        polje_ime.grid(row = 1, column = 0)
        gumb = Button(master, text = 'Podatki:', command = self.isci_poskodbe)
        gumb.grid(row = 2, column = 0)
        self.rezultat = IntVar(master, value = 0)
        polje_rezultat = Label(master, textvariable = self.rezultat)
        polje_rezultat.grid(row = 3, column = 0)
        
    def isci_poskodbe(self):
        leto = self.ime.get()
        tabela = poskodbe_z(leto)
        text = ''
        for elt in tabela:
            text += elt + '\n'
        if tabela:
            self.rezultat.set(text)
        else: self.rezultat.set('Ni podatka za to leto.')


def fetalne_smrti(leto):
    '''Vrne seznam števila splavov, drugih patoloških nosečnosti in izvenmaterničnih nosečnosti v Sloveniji v nekem letu.'''
    leto = int(leto)
    slov = 0
    with open('Fetalne_smrti.txt', 'r') as dat:
        podatki = list()
        for vrstica in dat:
            if slov == 1:
                tab = re.findall(r'[1-9][0-9]*', vrstica)
                for index in range(len(tab)):
                    vsota = 0
                    if int(tab[index]) == leto:
                        for j in range(1, 13):
                            vsota += int(tab[index+j])
                        podatki.append('{}-{}'.format(kljuc, str(vsota)))
                        slov = 0
            if 'Dovoljeni splavi =' in vrstica:
                kljuc = vrstica[:-4]
                slov = 1
            elif 'Izvenmaternične nosečnosti =' in vrstica:
                kljuc = vrstica[:-4]
                slov = 1
            elif 'Druge patološke nosečnosti =' in vrstica:
                kljuc = vrstica[:-4]
                slov = 1
            elif 'Spontani splavi =' in vrstica:
                kljuc = vrstica[:-4]
                slov = 1
    return podatki


class Fetalne_smrti:
    def __init__(self, master):
        vprasanje = Label(master, text = 'Vtipkajte željeno leto:')
        vprasanje.grid(row = 0, column = 0)
        self.ime = StringVar(master, value = None)
        polje_ime = Entry(master, textvariable = self.ime)
        polje_ime.grid(row = 1, column = 0)
        gumb = Button(master, text = 'Podatki:', command = self.isci_smrti)
        gumb.grid(row = 2, column = 0)
        self.rezultat = IntVar(master, value = 0)
        polje_rezultat = Label(master, textvariable = self.rezultat)
        polje_rezultat.grid(row = 3, column = 0)
    
    def isci_smrti(self):
        leto = self.ime.get()
        tabela = fetalne_smrti(leto)
        text = ''
        for elt in tabela:
            text += elt + '\n'
        if tabela:
            self.rezultat.set(text)
        else: self.rezultat.set('Ni podatka za to leto.')


class Pricakovana_leta_M:
    def __init__(self, master):
        vprasanje = Label(master, text = 'Vtipkajte željeno leto:')
        vprasanje.grid(row = 0, column = 0)
        self.ime = StringVar(master, value = None)
        polje_ime = Entry(master, textvariable = self.ime)
        polje_ime.grid(row = 1, column = 0)
        gumb = Button(master, text = 'Podatki:', command = self.isci_moski)
        gumb.grid(row = 2, column = 0)
        self.rezultat = IntVar(master, value = 0)
        polje_rezultat = Label(master, textvariable = self.rezultat)
        polje_rezultat.grid(row = 3, column = 0)
        
    def isci_moski(self):
        leto = self.ime.get()
        self.rezultat.set(moski_pricakovana_leta.get(leto, 0))
        
class Pricakovana_leta_Z:
    def __init__(self, master):
        vprasanje = Label(master, text = 'Vtipkajte željeno leto:')
        vprasanje.grid(row = 0, column = 0)
        self.ime = StringVar(master, value = None)
        polje_ime = Entry(master, textvariable = self.ime)
        polje_ime.grid(row = 1, column = 0)
        gumb = Button(master, text = 'Podatki:', command = self.isci_zenske)
        gumb.grid(row = 2, column = 0)
        self.rezultat = IntVar(master, value = 0)
        polje_rezultat = Label(master, textvariable = self.rezultat)
        polje_rezultat.grid(row = 3, column = 0)
        
    def isci_zenske(self):
        leto = self.ime.get()
        self.rezultat.set(zenske_pricakovana_leta.get(leto, 0))
        
class Porodi_M:
    def __init__(self, master):
        vprasanje = Label(master, text = 'Vtipkajte željeno leto:')
        vprasanje.grid(row = 0, column = 0)
        self.ime = StringVar(master, value = None)
        polje_ime = Entry(master, textvariable = self.ime)
        polje_ime.grid(row = 1, column = 0)
        gumb = Button(master, text = 'Podatki:', command = self.isci_m_porodi)
        gumb.grid(row = 2, column = 0)
        self.rezultat = IntVar(master, value = 0)
        polje_rezultat = Label(master, textvariable = self.rezultat)
        polje_rezultat.grid(row = 3, column = 0)
        
    def isci_m_porodi(self):
        leto = self.ime.get()
        self.rezultat.set(decki_rojstva.get(int(leto), 0))

class Porodi_Z:
    def __init__(self, master):
        vprasanje = Label(master, text = 'Vtipkajte željeno leto:')
        vprasanje.grid(row = 0, column = 0)
        self.ime = StringVar(master, value = None)
        polje_ime = Entry(master, textvariable = self.ime)
        polje_ime.grid(row = 1, column = 0)
        gumb = Button(master, text = 'Podatki:', command = self.isci_z_porodi)
        gumb.grid(row = 2, column = 0)
        self.rezultat = IntVar(master, value = 0)
        polje_rezultat = Label(master, textvariable = self.rezultat)
        polje_rezultat.grid(row = 3, column = 0)
        
    def isci_z_porodi(self):
        leto = self.ime.get()
        self.rezultat.set(deklice_rojstva.get(int(leto), 0))

def main(): 
    root = Tk()
    app = Spol(root)
    root.geometry("250x250")
    root.title('Zdravje v Sloveniji')
    root.mainloop()

if __name__ == '__main__':
    main()
