import re


with open('Porodi.htm', 'r') as datoteka:
    besedilo = datoteka.read()
    
    
    niz_posamezni_del = re.compile(
        r'<TR ALIGN=RIGHT>\s'
        r'<TH ALIGN=LEFT VALIGN=TOP>(?P<LETO>.*?)</TH>\s'
        r'<TD>(?P<DECKI>.*?)</TD>\s'
        r'<TD>(?P<DEKLICE>.*?)</TD>\s'
        r'</TR>\s',
        flags = re.DOTALL
        )   #z re.compile sem pregledno zgradila daljše nize; flags=re.DOTALL nam pove, da naj iščemo ustrezne nize, ki so daljši od ene vrstice
        
    
    
    #podatki za rojene deklice in dečke
    rojstva = re.findall(r'Rojstva</TH>(.*?)Živorojeni</TH>', besedilo, flags = re.DOTALL)[0]
    rojstva_podatki = [] #tabela kjer so shranjeni slovarji z ključem LETO, DECKI, DEKLICE in vrednostim leto, število rojenih dečkov, število rojenih deklic
    for zadetek in re.finditer(niz_posamezni_del, rojstva):
        rojstva_podatki.append(zadetek.groupdict())

    #podatki za živorojene deklice in dečke
    zivorojeni = re.findall(r'Živorojeni</TH>(.*)<TH ALIGN=LEFT VALIGN=TOP>Mrtvorojeni</TH>', besedilo, flags = re.DOTALL)[0]
    zivorojeni_podatki = [] #tabela kjer so shranjeni slovarji z ključem LETO, DECKI, DEKLICE in vrednostim leto, število živorojenih dečkov, število živorojenih deklic
    for zadetek in re.finditer(niz_posamezni_del, zivorojeni):
        zivorojeni_podatki.append(zadetek.groupdict())
        
    #podatki za mrtvorojene deklice in dečke
    mrtvorojeni = re.findall(r'<TH ALIGN=LEFT VALIGN=TOP>Mrtvorojeni</TH>(.*)Opomba:', besedilo, flags = re.DOTALL)[0]
    mrtvorojeni_podatki = [] #tabela kjer so shranjeni slovarji z ključem LETO, DECKI, DEKLICE in vrednostim leto, število mrtvorojenih dečkov, število mrtvorojenih deklic
    for zadetek in re.finditer(niz_posamezni_del, mrtvorojeni):
        mrtvorojeni_podatki.append(zadetek.groupdict())
        
        
        
    slovar_decki = {}  #slovar, kjer so posebej shranjeni podatki za dečke in so ključi leta, vrednosti pa tabele podatkov 
    slovar_deklice = {}  #slovar, kjer so posebej shranjeni podatki za deklice in so ključi leta, vrednosti pa tabele podatkov 
    slovar_slovarjev_decki = {}  #slovar, kjer so posebej shranjeni podatki za dečke in so ključi leta, vrednosti pa slovarji podatkov 
    slovar_slovarjev_deklice = {}  #slovar, kjer so posebej shranjeni podatki za deklice in so ključi leta, vrednosti pa slovarji podatkov 
    dolzina = len(rojstva_podatki)
    for indeks in range(dolzina):
        slovar_rojst = rojstva_podatki[indeks]
        slovar_zivo = zivorojeni_podatki[indeks]
        slovar_mrtvo = mrtvorojeni_podatki[indeks]
             
        leto = int(slovar_rojst['LETO'])
             
        rojstva_decki = slovar_rojst['DECKI']
        rojstva_deklice = slovar_rojst['DEKLICE']
             
        zivorojeni_decki = slovar_zivo['DECKI']
        zivorojene_deklice = slovar_zivo['DEKLICE']
             
        mrtvorojeni_decki = slovar_mrtvo['DECKI']
        mrtvorojene_deklice = slovar_mrtvo['DEKLICE']
             
        slovar_decki[leto] = ['Rojstva: ', rojstva_decki, 'Živorojeni: ', zivorojeni_decki, 'Mrtvorojeni: ', mrtvorojeni_decki]
        slovar_deklice[leto] = ['Rojstva: ', rojstva_deklice, 'Živorojeni: ', zivorojene_deklice, 'Mrtvorojeni: ', mrtvorojene_deklice]
        
        slovar_slovarjev_decki[leto] = {rojstva_decki, zivorojeni_decki, mrtvorojeni_decki}
        slovar_slovarjev_deklice[leto] = {rojstva_deklice, zivorojene_deklice, mrtvorojene_deklice}
       
       
        
#izpiše slovarja tabel v datoteko 
with open("Porodi.txt", "w") as izpis:
    print("moski = ", file=izpis)
    print(slovar_decki, file=izpis)
    print("zenske = ", file=izpis)
    print(slovar_deklice, file=izpis)
    
             
        
##########################################################################################################################################################################################


with open("Fetalne_smrti.htm",'r') as datoteka:
    besedilo = datoteka.read()  
     
    niz_posamezni_del = re.compile(
        r'<TR ALIGN=RIGHT>\s'
        r'<TH ALIGN=LEFT VALIGN=TOP>(?P<LETO>.*?)</TH>\s'
        r'<TD>(?P<POMURSKA>.*?)</TD>\s'
        r'<TD>(?P<PODRAVSKA>.*?)</TD>\s'
        r'<TD>(?P<KOROŠKA>.*?)</TD>\s'
        r'<TD>(?P<SAVINJSKA>.*?)</TD>\s'
        r'<TD>(?P<ZASAVSKA>.*?)</TD>\s'
        r'<TD>(?P<POSAVSKA>.*?)</TD>\s'
        r'<TD>(?P<JUGOVZHODNA_SLOVENIJA>.*?)</TD>\s'
        r'<TD>(?P<OSREDNJESLOVENJSKA>.*?)</TD>\s'
        r'<TD>(?P<GORENJSKA>.*?)</TD>\s'
        r'<TD>(?P<PRIMORSKO_NOTRANJSKA>.*?)</TD>\s'
        r'<TD>(?P<GORIŠKA>.*?)</TD>\s'
        r'<TD>(?P<OBALNO_KRAŠKA>.*?)</TD>\s',
        flags = re.DOTALL
        )
    
    #podatki za dovoljene splave
    dovoljeni_splavi = re.findall(r'Dovoljeni splavi(.*)Spontani splavi</TH>', besedilo, flags = re.DOTALL)[0]
    dovoljeni_splavi_podatki = {}  #slovar, kjer so ključi leta, vrednosti pa tabele podatkov
    dovoljeni_splavi_podatki_slovar_slovarjev = {}   #slovar, kjer so ključi leta, vrednosti pa slovarji podatkov
    for zadetek in re.finditer(niz_posamezni_del, dovoljeni_splavi):
        slovar3 = zadetek.groupdict()
        dovoljeni_splavi_podatki[slovar3["LETO"]] = [": ".join([key,value])for key, value in slovar3.items() if key != "LETO"]
        dovoljeni_splavi_podatki_slovar_slovarjev[slovar3["LETO"]] = {key: value for key, value in slovar3.items() if key != "LETO"}
        
    #podatki za spontane splave 
    spontani_splavi = re.findall(r'Spontani splavi(.*)Druge patološke nosečnosti</TH>', besedilo, flags = re.DOTALL)[0]
    spontani_splavi_podatki = {} #slovar, kjer so ključi leta, vrednosti pa tabele podatkov
    spontani_splavi_podatki_slovar_slovarjev = {}  #slovar, kjer so ključi leta, vrednosti pa slovarji podatkov
    for zadetek in re.finditer(niz_posamezni_del, spontani_splavi):
        slovar4 = zadetek.groupdict()
        spontani_splavi_podatki[slovar4["LETO"]] = [": ".join([key,value])for key, value in slovar4.items() if key != "LETO"]
        spontani_splavi_podatki_slovar_slovarjev[slovar4["LETO"]] = {key: value for key, value in slovar4.items() if key != "LETO"}

    #podatki za patološke nosečnosti
    druge_patoloske_nosecnosti = re.findall(r'Druge patološke nosečnosti(.*)Izvenmaternične nosečnosti</TH>', besedilo, flags = re.DOTALL)[0]
    druge_patoloske_nosecnosti_podatki = {}  #slovar, kjer so ključi leta, vrednosti pa tabele podatkov
    druge_patoloske_nosecnosti_podatki_slovar_slovarjev = {}     #slovar, kjer so ključi leta, vrednosti pa slovarji podatkov
    for zadetek in re.finditer(niz_posamezni_del, druge_patoloske_nosecnosti):
        slovar5 = zadetek.groupdict()
        druge_patoloske_nosecnosti_podatki[slovar5["LETO"]] = [": ".join([key,value])for key, value in slovar5.items() if key != "LETO"]
        druge_patoloske_nosecnosti_podatki_slovar_slovarjev[slovar5["LETO"]] = {key: value for key, value in slovar5.items() if key != "LETO"}


    #izvenmaternične nosečnosti
    izvenmaternicne_nosecnosti = re.findall(r'Izvenmaternične nosečnosti(.*)Opombe:', besedilo, flags = re.DOTALL)[0]
    izvenmaternicne_nosecnosti_podatki = {}  #slovar, kjer so ključi leta, vrednosti pa tabele podatkov
    izvenmaternicne_nosecnosti_podatki_slovar_slovarjev = {}  #slovar, kjer so ključi leta, vrednosti pa slovarji podatkov
    for zadetek in re.finditer(niz_posamezni_del, izvenmaternicne_nosecnosti):
        slovar6 = zadetek.groupdict()
        izvenmaternicne_nosecnosti_podatki[slovar6["LETO"]] = [": ".join([key,value])for key, value in slovar6.items() if key != "LETO"]
        izvenmaternicne_nosecnosti_podatki_slovar_slovarjev[slovar6["LETO"]] = {key: value for key, value in slovar6.items() if key != "LETO"}


#izpiše slovarje tabel v datoteko za aplikacijo tinker  
with open("Fetalne_smrti.txt", "w") as izpis:
    print("Dovoljeni splavi = ", file=izpis)
    print(dovoljeni_splavi_podatki, file=izpis)
    print("Spontani splavi =  ", file=izpis)
    print(spontani_splavi_podatki, file=izpis)
    print("Druge patološke nosečnosti = ", file=izpis)
    print(druge_patoloske_nosecnosti_podatki, file=izpis)
    print("Izvenmaternične nosečnosti =  ", file=izpis)
    print(izvenmaternicne_nosecnosti_podatki, file=izpis)
#izpiše slovarje slovarjev v datoteko za grafe 
with open("Fetalne_smrti_slovarji_slovarjev.txt", "w") as izpis:
    print("Dovoljeni splavi = ", file=izpis)
    print(dovoljeni_splavi_podatki_slovar_slovarjev, file=izpis)
    print("Spontani splavi =  ", file=izpis)
    print(spontani_splavi_podatki_slovar_slovarjev, file=izpis)
    print("Druge patološke nosečnosti = ", file=izpis)
    print(druge_patoloske_nosecnosti_podatki_slovar_slovarjev, file=izpis)
    print("Izvenmaternične nosečnosti =  ", file=izpis)
    print(izvenmaternicne_nosecnosti_podatki_slovar_slovarjev, file=izpis)
        
        
#########################################################################################################################################################################################        
    

with open("Število_umrlih.htm",'r') as datoteka:
    besedilo = datoteka.read() 

    niz_posamezen_del = re.compile(
        r'<TR ALIGN=RIGHT>\s'
        r'<TH ALIGN=LEFT VALIGN=TOP>(?P<LETO>\d*)</TH>\s'
        r'<TD>(?P<UMRLI>\d*.\d*)</TD>\s'
        r'<TD>(?P<POVPREČNA_STAROST_UMRLIH>\d*.\d*)</TD>\s'
        r'<TD>(?P<UMRLI_DOJENČKI>\d*)</TD>\s',
        flags=re.DOTALL
    ) 

    #podatki za moške
    del_za_moske = re.findall(r'Moški(.*)Ženske</TH>\s*</TR>', besedilo, flags=re.DOTALL)[0]
    podatki_moski = {} #izpis v slovarju z ključem leta in vrednostjo tabela
    podatki_moski_slovar = {} #izpis v slovarju z ključem leta in vrednostjo slovarjem
    for zadetek in re.finditer(niz_posamezen_del, del_za_moske):
        slovar1 = zadetek.groupdict()
        podatki_moski[slovar1["LETO"]] = [": ".join([key,value]) for key, value in slovar1.items() if key != "LETO"]
        podatki_moski_slovar[slovar1["LETO"]] = {key: value for key, value in slovar1.items() if key != "LETO"}


    #podatki za ženske
    del_za_zenske = re.findall(r'Ženske(.*)Vir: ', besedilo, flags=re.DOTALL)[0]
    podatki_zenske = {}
    podatki_zenske_slovar = {}
    for zadetek in re.finditer(niz_posamezen_del, del_za_zenske):
        slovar2 = zadetek.groupdict()
        podatki_zenske[slovar2["LETO"]] = [": ".join([key,value])for key, value in slovar2.items() if key != "LETO"]
        podatki_zenske_slovar[slovar2["LETO"]] = {key: value for key, value in slovar2.items() if key != "LETO"}

    
#izpiše slovarja tabel v datoteko     
with open("Umrli_M.txt", "w") as izpis:
    print("Moški = ", file=izpis)
    print(podatki_moski, file=izpis)
    
with open("Umrli_Z.txt", "w") as izpis:
    print("Ženske = ", file=izpis)
    print(podatki_zenske, file=izpis)
    
#######################################################################################################################################################################################

tab_podatkov = list()
with open('Spolne_bolezni.htm') as f:
    for vrstica in f:
        pogoj1 = re.match(r'<TD>', vrstica)
        try:
            pogoj1.group()
            # imamo podatek
            stevilo = re.findall(r'[1-9][0-9]*', vrstica)
            if len(stevilo) == 0:
                # podatek = 0
                
                tab_podatkov.append('0')
            else: tab_podatkov.append(stevilo[0])
        except: continue

bolezni = ['HIV', 'AIDS', 'Zgodnji sifilis', 'Pozni sifilis', 'Neopredeljeni sifilis', 'Gonoreja', 'Klamidijska okužba']

slovar_moski = {'HIV': list(),
       'AIDS': list(),
       'Zgodnji sifilis': list(),
       'Pozni sifilis': list(),
       'Neopredeljeni sifilis': list(),
       'Gonoreja': list(),
       'Klamidijska okužba': list()}

slovar_zenske = {'HIV': list(),
       'AIDS': list(),
       'Zgodnji sifilis': list(),
       'Pozni sifilis': list(),
       'Neopredeljeni sifilis': list(),
       'Gonoreja': list(),
       'Klamidijska okužba': list()}

# podatki za ženske
ind_bolezni = 0
for elt in range(8, len(tab_podatkov), 16):
    if ind_bolezni == 7:
        ind_bolezni = 0
    vsota = 0
    for j in range(0, 8):
        vsota += int(tab_podatkov[elt+j])
    slovar_zenske[bolezni[ind_bolezni]].append(vsota)
    ind_bolezni += 1

#podatki za moške
ind_bolezni = 0
for elt in range(0, len(tab_podatkov), 16):
    if ind_bolezni == 7:
        ind_bolezni = 0
    vsota = 0
    for j in range(0, 8):
        vsota += int(tab_podatkov[elt+j])
    slovar_moski[bolezni[ind_bolezni]].append(vsota)
    ind_bolezni += 1

# zapis podatkov po letih
zenske_podatki = dict()
moski_podatki = dict()
for leto in range(2005, 2018):
    zenske_podatki[str(leto)] = list()
    moski_podatki[str(leto)] = list()

i = -1
for leto  in range(2005, 2018):
    i += 1
    for kljuc in bolezni: 
        zenske_podatki[str(leto)].append('{}: {}'.format(kljuc, slovar_zenske[kljuc][i]))

i = -1
for leto  in range(2005, 2018):
    i += 1
    for kljuc in bolezni: 
        moski_podatki[str(leto)].append('{}: {}'.format(kljuc, slovar_moski[kljuc][i]))

#izpiše slovarja tabel v datoteko za aplikacijo tkinter    
with open("Bolezni_M.txt", "w") as izpis:
    print("Moški = ", file=izpis)
    print(moski_podatki, file=izpis)
    
#izpiše slovarja tabel v datoteko za aplikacijo tkinter    
with open("Bolezni_Z.txt", "w") as izpis:
    print("Ženske = ", file=izpis)
    print(zenske_podatki, file=izpis)

###################################################################################################

tab_podatkov = list()
with open('Poškodbe_pri_delu.htm') as f:
    for vrstica in f:
        pogoj1 = re.match(r'<TD>', vrstica)
        try:
            pogoj1.group()
            # imamo podatek
            stevilo = re.findall(r'[1-9][0-9]*', vrstica)
            if len(stevilo) == 0:
                # podatek = 0
                tab_podatkov.append('0')
            elif len(stevilo) == 2:
                celo_stevilo = stevilo[0] + stevilo[1]
                tab_podatkov.append(celo_stevilo)
            else: tab_podatkov.append(stevilo[0])
        except: continue

primeri_prijav = ['Na običajnem delovnem mestu', 'Začasno delovno mesto v isti enoti', 'Službena pot ali delovno mesto v drugi enoti', 'Pot na delo', 'Pot z dela']

slovar_moski = {'Na običajnem delovnem mestu': list(),
                'Začasno delovno mesto v isti enoti': list(),
                'Službena pot ali delovno mesto v drugi enoti': list(),
                'Pot na delo': list(),
                'Pot z dela': list()}

slovar_zenske = {'Na običajnem delovnem mestu': list(),
                'Začasno delovno mesto v isti enoti': list(),
                'Službena pot ali delovno mesto v drugi enoti': list(),
                'Pot na delo': list(),
                'Pot z dela': list()}

# podatki za ženske
ind_primera = 0
for elt in range(6, len(tab_podatkov), 12):
    if ind_primera == 5:
        ind_primera = 0
    vsota = 0
    for j in range(0, 6):
        
        vsota += int(tab_podatkov[elt+j])
    slovar_zenske[primeri_prijav[ind_primera]].append(vsota)
    ind_primera += 1

# podatki za moške
ind_primera = 0
for elt in range(0, len(tab_podatkov), 12):
    if ind_primera == 5:
        ind_primera = 0
    vsota = 0
    for j in range(0, 6):
        vsota += int(tab_podatkov[elt+j])
    slovar_moski[primeri_prijav[ind_primera]].append(vsota)
    ind_primera += 1

# zapis podatkov po letih
leto = 2008
slovar1_moski = dict()
slovar2_moski = dict()
slovar3_moski = dict()
slovar4_moski = dict()
slovar5_moski = dict()
for i in range(11):
    slovar1_moski[leto] = slovar_moski['Na običajnem delovnem mestu'][i]
    slovar2_moski[leto] = slovar_moski['Začasno delovno mesto v isti enoti'][i]
    slovar3_moski[leto] = slovar_moski['Službena pot ali delovno mesto v drugi enoti'][i]
    slovar4_moski[leto] = slovar_moski['Pot na delo'][i]
    slovar5_moski[leto] = slovar_moski['Pot z dela'][i]
    leto += 1

leto = 2008
slovar1_zenske = dict()
slovar2_zenske = dict()
slovar3_zenske = dict()
slovar4_zenske = dict()
slovar5_zenske = dict()
for i in range(11):
    slovar1_zenske[leto] = slovar_zenske['Na običajnem delovnem mestu'][i]
    slovar2_zenske[leto] = slovar_zenske['Začasno delovno mesto v isti enoti'][i]
    slovar3_zenske[leto] = slovar_zenske['Službena pot ali delovno mesto v drugi enoti'][i]
    slovar4_zenske[leto] = slovar_zenske['Pot na delo'][i]
    slovar5_zenske[leto] = slovar_zenske['Pot z dela'][i]
    leto += 1
    
# zapis datoteke za moške    
with open('Poskodbe_M.txt', 'w') as izpis:
    print('Moški = ', file=izpis)
    print('Na običajnem delovnem mestu', file=izpis)
    print(slovar1_moski, file=izpis)
    print('Začasno delovno mesto v isti enoti', file=izpis)
    print(slovar2_moski, file=izpis)
    print('Službena pot ali delovno mesto v drugi enoti', file=izpis)
    print(slovar3_moski, file=izpis)
    print('Pot na delo', file=izpis)
    print(slovar4_moski, file=izpis)
    print('Pot z dela', file=izpis)
    print(slovar5_moski, file=izpis)
    
# zapis datoteke za ženske
with open('Poskodbe_Z.txt', 'w') as izpis:
    print('Ženske = ', file=izpis)
    print('Na običajnem delovnem mestu', file=izpis)
    print(slovar1_zenske, file=izpis)
    print('Začasno delovno mesto v isti enoti', file=izpis)
    print(slovar2_zenske, file=izpis)
    print('Službena pot ali delovno mesto v drugi enoti', file=izpis)
    print(slovar3_zenske, file=izpis)
    print('Pot na delo', file=izpis)
    print(slovar4_zenske, file=izpis)
    print('Pot z dela', file=izpis)
    print(slovar5_zenske, file=izpis)


################################################################################################################################################################################

import re

tab_podatkov = list()
with open('Zdrava_leta_zivljenja.htm') as f:
    for vrstica in f:
        pogoj1 = re.match(r'<TD>', vrstica)
        try:
            pogoj1.group()
            # imamo podatek
            stevilo = re.findall(r'[1-9][0-9]*', vrstica)
            if len(stevilo) == 1:
                # podatek je celo število                
                tab_podatkov.append(stevilo[0])
            else:
                podatek = stevilo[0] + ',' + stevilo[1]
                tab_podatkov.append(podatek)
        except: continue
        
spremenljivke = ['Ob rojstvu', '50 let', '65 let']

# podatki za analizo
slovar_moski = {'Ob rojstvu': list(),
                 '50 let': list(),
                 '65 let': list()}
slovar_zenske = {'Ob rojstvu': list(),
                 '50 let': list(),
                 '65 let': list()}
spodnja_meja = 0
for kljuc in spremenljivke:
    for i in range(spodnja_meja, len(tab_podatkov), 42):
        if i == spodnja_meja:
            for j in range(14):
                slovar_moski[kljuc].append(tab_podatkov[i+j])
        else: 
            for j in range(14):
                slovar_zenske[kljuc].append(tab_podatkov[i+j])
    spodnja_meja += 14



# ustvarjanje ustreznega slovarja za program
zenske_podatki = dict()
moski_podatki = dict()
for leto in range(2005, 2019):
    zenske_podatki[str(leto)] = list()
    moski_podatki[str(leto)] = list()

i = -1
for leto  in range(2005, 2019):
    i += 1
    for kljuc in spremenljivke: 
        zenske_podatki[str(leto)].append('{}: {}'.format(kljuc, slovar_zenske[kljuc][i]))
i = -1
for leto  in range(2005, 2019):
    i += 1
    for kljuc in spremenljivke: 
        moski_podatki[str(leto)].append('{}: {}'.format(kljuc, slovar_moski[kljuc][i]))
        
# zapis podatkov v datoteko
with open("Zdrava_leta_življenja.txt", "w") as izpis:
    print("Moski_podatki = ", moski_podatki, file=izpis)
    print("Zenski_podatki = ", zenske_podatki, file=izpis)