import matplotlib
import matplotlib.pyplot as plt
import numpy as np

###########################################################Datoteka umrli################################################################################################################
    
zenske = {'2005': ['UMRLI: 9.412', 'POVPREČNA_STAROST_UMRLIH: 77,8', 'UMRLI_DOJENČKI: 34'], '2006': ['UMRLI: 8.910', 'POVPREČNA_STAROST_UMRLIH: 78,1', 'UMRLI_DOJENČKI: 32'], '2007': ['UMRLI: 9.111', 'POVPREČNA_STAROST_UMRLIH: 78,2', 'UMRLI_DOJENČKI: 28'], '2008': ['UMRLI: 9.134', 'POVPREČNA_STAROST_UMRLIH: 78,8', 'UMRLI_DOJENČKI: 22'], '2009': ['UMRLI: 9.457', 'POVPREČNA_STAROST_UMRLIH: 79,1', 'UMRLI_DOJENČKI: 27'], '2010': ['UMRLI: 9.317', 'POVPREČNA_STAROST_UMRLIH: 79,3', 'UMRLI_DOJENČKI: 32'], '2011': ['UMRLI: 9.464', 'POVPREČNA_STAROST_UMRLIH: 79,7', 'UMRLI_DOJENČKI: 23'], '2012': ['UMRLI: 9.845', 'POVPREČNA_STAROST_UMRLIH: 80,0', 'UMRLI_DOJENČKI: 18'], '2013': ['UMRLI: 9.779', 'POVPREČNA_STAROST_UMRLIH: 80,3', 'UMRLI_DOJENČKI: 30'], '2014': ['UMRLI: 9.678', 'POVPREČNA_STAROST_UMRLIH: 80,9', 'UMRLI_DOJENČKI: 20'], '2015': ['UMRLI: 10.095', 'POVPREČNA_STAROST_UMRLIH: 81,0', 'UMRLI_DOJENČKI: 15'], '2016': ['UMRLI: 10.016', 'POVPREČNA_STAROST_UMRLIH: 81,4', 'UMRLI_DOJENČKI: 21'], '2017': ['UMRLI: 10.373', 'POVPREČNA_STAROST_UMRLIH: 81,4', 'UMRLI_DOJENČKI: 21'], '2018': ['UMRLI: 10.372', 'POVPREČNA_STAROST_UMRLIH: 81,6', 'UMRLI_DOJENČKI: 11']}
moski = {'2005': ['UMRLI: 9.413', 'POVPREČNA_STAROST_UMRLIH: 68,9', 'UMRLI_DOJENČKI: 41'], '2006': ['UMRLI: 9.270', 'POVPREČNA_STAROST_UMRLIH: 68,5', 'UMRLI_DOJENČKI: 32'], '2007': ['UMRLI: 9.473', 'POVPREČNA_STAROST_UMRLIH: 69,1', 'UMRLI_DOJENČKI: 27'], '2008': ['UMRLI: 9.174', 'POVPREČNA_STAROST_UMRLIH: 69,9', 'UMRLI_DOJENČKI: 30'], '2009': ['UMRLI: 9.293', 'POVPREČNA_STAROST_UMRLIH: 70,1', 'UMRLI_DOJENČKI: 25'], '2010': ['UMRLI: 9.292', 'POVPREČNA_STAROST_UMRLIH: 70,7', 'UMRLI_DOJENČKI: 24'], '2011': ['UMRLI: 9.235', 'POVPREČNA_STAROST_UMRLIH: 71,2', 'UMRLI_DOJENČKI: 41'], '2012': ['UMRLI: 9.412', 'POVPREČNA_STAROST_UMRLIH: 71,8', 'UMRLI_DOJENČKI: 18'], '2013': ['UMRLI: 9.555', 'POVPREČNA_STAROST_UMRLIH: 71,9', 'UMRLI_DOJENČKI: 32'], '2014': ['UMRLI: 9.208', 'POVPREČNA_STAROST_UMRLIH: 72,7', 'UMRLI_DOJENČKI: 19'], '2015': ['UMRLI: 9.739', 'POVPREČNA_STAROST_UMRLIH: 72,8', 'UMRLI_DOJENČKI: 18'], '2016': ['UMRLI: 9.673', 'POVPREČNA_STAROST_UMRLIH: 73,0', 'UMRLI_DOJENČKI: 20'], '2017': ['UMRLI: 10.136', 'POVPREČNA_STAROST_UMRLIH: 74,0', 'UMRLI_DOJENČKI: 21'], '2018': ['UMRLI: 10.113', 'POVPREČNA_STAROST_UMRLIH: 74,1', 'UMRLI_DOJENČKI: 22']}    
      
x_os = [] #v tabelo izpišem leta 
umrli_z_1 = [] #v tabelo izpišem podatke za umrle ženske za posamezno leto
umrli_dojencki_z_1 = []   #v tabelo izpišem podatke za umrle dojenčke(ženskega spola) za posamezno leto
for kljuc, vrednost in zenske.items():
    x_os.append(kljuc)
    
    umrli_z_1.append(vrednost[0])  #podatek za umrle je v tabeli na prvem mestu
    umrli_z = []  #v tabelo izpišem podatke(samo številke) za umrle(ženskega spola) za posamezno leto
    for i in umrli_z_1:
        podatek = str(i)
        l = i.split(':')[1]
        st_l = float(l)
        umrli_z.append(st_l)
    

    umrli_dojencki_z_1.append(vrednost[2]) #podatek za umrle je v tabeli na tretjem mestu
    umrli_dojencki_z = []   #v tabelo izpišem podatke(samo številke) za umrle dojenčke(ženskega spola) za posamezno leto
    for k in umrli_dojencki_z_1:
        podatek = str(k)
        n = k.split(':')[1]
        st_n = int(n)
        umrli_dojencki_z.append(st_n)



umrli_m_1 = []   #v tabelo izpišem podatke za umrle moške za posamezno leto
umrli_dojencki_m_1 = []   #v tabelo izpišem podatke za umrle dojenčke(moškega spola) za posamezno leto
for kljuc,vrednost in moski.items():
    
    umrli_m_1.append(vrednost[0]) #podatek za umrle je v tabeli na prvem mestu
    umrli_m = []   #v tabelo izpišem podatke(samo številke) za umrle(moškega spola) za posamezno leto
    for i in umrli_m_1:
        podatek = str(i)
        l = i.split(':')[1]
        st_l = float(l)
        umrli_m.append(st_l)
    

    umrli_dojencki_m_1.append(vrednost[2])    #podatek za umrle je v tabeli na tretjem mestu
    umrli_dojencki_m = []    #v tabelo izpišem podatke(samo številke) za umrle dojenčke(moškega spola) za posamezno leto
    for k in umrli_dojencki_m_1:
        podatek = str(k)
        n = k.split(':')[1]
        st_n = int(n)
        umrli_dojencki_m.append(st_n)


# #########################################################Figure 1######################################################################################################################
#Stolpični diagram z dvema stolpcema za vsako vrednost na x-osi
# x-os = leta(x_os)
# prvi stolpec = umrli moški(umrli_z)
# drugi stolpec = umrle ženske(umrli_m)

x = np.arange(len(x_os))   #vrne enakomerno razporejene vrednosti znotraj določenega intervala
width = 0.45  #širina stolpcev

fig, ax = plt.subplots()
prvi_stolpec = ax.bar(x - width/2, umrli_m, width, color = 'blue', label='Moški')
drugi_stolpec = ax.bar(x + width/2, umrli_z, width, color = 'pink', label='Ženske')


ax.set_ylabel('Število umrlih')
ax.set_xlabel('Leta')
ax.set_title('Graf podatkov o umrlih')
ax.set_xticks(x)
ax.set_xticklabels(x_os)
ax.legend()

ax.bar_label(prvi_stolpec,padding=0)
ax.bar_label(drugi_stolpec, padding=6)

fig.tight_layout()

plt.show()

#########################################################Figure 2#######################################################################################################################
#Stolpični diagram z dvema stolpcema za vsako vrednost na x-osi
# x-os = leta(x_os)
# prvi stolpec = umrli dojenčki moškega spola(umrli_dojencki_z)
# drugi stolpec = umrli dojenčki ženskega spola(umrli_dojencki_m)



x = np.arange(len(x_os))   
width = 0.30  

fig, ax = plt.subplots()
prvi_stolpec = ax.bar(x - width/2, umrli_dojencki_m, width, color = 'cornflowerblue', label='Fantki')
drugi_stolpec = ax.bar(x + width/2, umrli_dojencki_z, width, color = 'magenta', label='Deklice')


ax.set_ylabel('Število umrlih')
ax.set_xlabel('Leta')
ax.set_title('Graf podatkov o umrlih dojenčkih')
ax.set_xticks(x)
ax.set_xticklabels(x_os)
ax.legend()

ax.bar_label(prvi_stolpec,padding=3)
ax.bar_label(drugi_stolpec, padding=3)

fig.tight_layout()

plt.show()
#####################################################Datoteka rojstva##############################################################################################################################

decki = {2005: ['Rojstva: ', '9.376', 'Živorojeni: ', '9.323', 'Mrtvorojeni: ', '53'], 2006: ['Rojstva: ', '9.814', 'Živorojeni: ', '9.772', 'Mrtvorojeni: ', '42'], 2007: ['Rojstva: ', '10.213', 'Živorojeni: ', '10.166', 'Mrtvorojeni: ', '47'], 2008: ['Rojstva: ', '11.173', 'Živorojeni: ', '11.107', 'Mrtvorojeni: ', '66'], 2009: ['Rojstva: ', '11.281', 'Živorojeni: ', '11.214', 'Mrtvorojeni: ', '67'], 2010: ['Rojstva: ', '11.503', 'Živorojeni: ', '11.454', 'Mrtvorojeni: ', '49'], 2011: ['Rojstva: ', '11.196', 'Živorojeni: ', '11.140', 'Mrtvorojeni: ', '56'], 2012: ['Rojstva: ', '11.253', 'Živorojeni: ', '11.201', 'Mrtvorojeni: ', '52'], 2013: ['Rojstva: ', '10.689', 'Živorojeni: ', '10.642', 'Mrtvorojeni: ', '47'], 2014: ['Rojstva: ', '10.773', 'Živorojeni: ', '10.720', 'Mrtvorojeni: ', '53'], 2015: ['Rojstva: ', '10.427', 'Živorojeni: ', '10.368', 'Mrtvorojeni: ', '59'], 2016: ['Rojstva: ', '10.246', 'Živorojeni: ', '10.185', 'Mrtvorojeni: ', '61'], 2017: ['Rojstva: ', '10.339', 'Živorojeni: ', '10.282', 'Mrtvorojeni: ', '57'], 2018: ['Rojstva: ', '10.031', 'Živorojeni: ', '9.984', 'Mrtvorojeni: ', '47']}
deklice = {2005: ['Rojstva: ', '8.823', 'Živorojeni: ', '8.765', 'Mrtvorojeni: ', '58'], 2006: ['Rojstva: ', '9.215', 'Živorojeni: ', '9.175', 'Mrtvorojeni: ', '40'], 2007: ['Rojstva: ', '9.702', 'Živorojeni: ', '9.648', 'Mrtvorojeni: ', '54'], 2008: ['Rojstva: ', '10.693', 'Živorojeni: ', '10.650', 'Mrtvorojeni: ', '43'], 2009: ['Rojstva: ', '10.482', 'Živorojeni: ', '10.430', 'Mrtvorojeni: ', '52'], 2010: ['Rojstva: ', '10.793', 'Živorojeni: ', '10.742', 'Mrtvorojeni: ', '51'], 2011: ['Rojstva: ', '10.650', 'Živorojeni: ', '10.594', 'Mrtvorojeni: ', '56'], 2012: ['Rojstva: ', '10.536', 'Živorojeni: ', '10.493', 'Mrtvorojeni: ', '43'], 2013: ['Rojstva: ', '10.186', 'Živorojeni: ', '10.135', 'Mrtvorojeni: ', '51'], 2014: ['Rojstva: ', '10.084', 'Živorojeni: ', '10.048', 'Mrtvorojeni: ', '36'], 2015: ['Rojstva: ', '9.853', 'Živorojeni: ', '9.813', 'Mrtvorojeni: ', '40'], 2016: ['Rojstva: ', '9.837', 'Živorojeni: ', '9.800', 'Mrtvorojeni: ', '37'], 2017: ['Rojstva: ', '9.608', 'Živorojeni: ', '9.566', 'Mrtvorojeni: ', '42'], 2018: ['Rojstva: ', '9.298', 'Živorojeni: ', '9.261', 'Mrtvorojeni: ', '37']}

#podatki za dečke
rojstva_m = [] #v tabelo shrani števila rojenih dečkov
zivo_m = []  #v tabelo shrani števila živorojenih dečkov
mrtvo_m = [] #v tabelo shrani števila mrtvorojenih dečkov
x_os_1 = []   #v tabelo shrani leta
for kl, vr in decki.items():
    x_os_1.append(kljuc)
    rojstva_m.append(float(vr[1]))
    zivo_m.append(float(vr[3]))
    mrtvo_m.append(float(vr[5]))

        
#podatki za deklice       
rojstva_z = []  #v tabelo shrani števila rojenih deklic
zivo_z = []  #v tabelo shrani števila živorojenih deklic
mrtvo_z = [] #v tabelo shrani števila mrtvorojenih deklic
for kl, vr in deklice.items():
    rojstva_z.append(float(vr[1]))
    zivo_z.append(float(vr[3]))
    mrtvo_z.append(int(vr[5]))
    
def vsota(tabela):
    '''Funkcija, ki vrne vsoto vseh podatkov v tabeli.'''
    sestevek =  0
    for d in tabela:
        st = float(d)
        sestevek += st
        st += 1
    return sestevek


#########################################################Figure 3######################################################################################################################
#Stolpični diagram z dvema stolpcema za vsako vrednost na x-osi
# x-os = leta(x_os_1)
# prvi stolpec = število rojenih dečkov(rojstva_m)
# drugi stolpec = število rojenih deklic(rojstva_z)

x = np.arange(len(x_os_1))   
width = 0.30  

fig, ax = plt.subplots()
prvi_stolpec = ax.bar(x - width/2, rojstva_m, width, color = 'cornflowerblue', label='Fantki')
drugi_stolpec = ax.bar(x + width/2, rojstva_z, width, color = 'magenta', label='Deklice')


ax.set_ylabel('Število rojenih')
ax.set_xlabel('Leta')
ax.set_title('Graf podatkov o rojstvih')
ax.set_xticks(x)
ax.set_xticklabels(x_os)
ax.legend()

ax.bar_label(prvi_stolpec,padding=3)
ax.bar_label(drugi_stolpec, padding=3)

fig.tight_layout()

plt.show()
#########################################################Figure 4#######################################################################################################################
#Dva tortna diagrama za živorojene in mrtvorojene dečke in deklice

oznake = 'Dečki', 'Deklice'
velikosti1 = [vsota(mrtvo_m), vsota(mrtvo_z)]
velikosti2 = [vsota(zivo_m), vsota(zivo_z)]
explode = (0.1,0.1)

#mrtvorojeni
fig, (ax1, ax2) = plt.subplots(ncols=2, figsize=(8, 4))
ax1.pie(velikosti1, explode=explode, labels=oznake, autopct='%1.1f%%', shadow=True, startangle=90)
ax1.axis('equal')  # Equal aspect ratio ensures that pie is drawn as a circle.
ax1.set_title('Graf podatkov mrtvorojenih od leta 2005 do 2018')

#zivorojeni
ax2.pie(velikosti2, explode=explode, labels=oznake, autopct='%1.1f%%', shadow=True, startangle=90)
ax2.axis('equal')  
ax2.set_title('Graf podatkov živorojenih od leta 2005 do 2018')

plt.show()
#######################################################Datoteka spolne bolezni###################################################################################################################################
spolne_bolezni_moski =  {'2005': ['HIV: 36', 'AIDS: 8', 'Zgodnji sifilis: 28', 'Pozni sifilis: 5', 'Neopredeljeni sifilis: 2', 'Gonoreja: 30', 'Klamidijska okužba: 101'], '2006': ['HIV: 29', 'AIDS: 4', 'Zgodnji sifilis: 12', 'Pozni sifilis: 4', 'Neopredeljeni sifilis: 0', 'Gonoreja: 33', 'Klamidijska okužba: 88'], '2007': ['HIV: 35', 'AIDS: 7', 'Zgodnji sifilis: 23', 'Pozni sifilis: 2', 'Neopredeljeni sifilis: 4', 'Gonoreja: 35', 'Klamidijska okužba: 145'], '2008': ['HIV: 46', 'AIDS: 9', 'Zgodnji sifilis: 61', 'Pozni sifilis: 5', 'Neopredeljeni sifilis: 14', 'Gonoreja: 41', 'Klamidijska okužba: 91'], '2009': ['HIV: 40', 'AIDS: 16', 'Zgodnji sifilis: 45', 'Pozni sifilis: 8', 'Neopredeljeni sifilis: 11', 'Gonoreja: 25', 'Klamidijska okužba: 99'], '2010': ['HIV: 31', 'AIDS: 7', 'Zgodnji sifilis: 35', 'Pozni sifilis: 1', 'Neopredeljeni sifilis: 6', 'Gonoreja: 42', 'Klamidijska okužba: 115'], '2011': ['HIV: 48', 'AIDS: 12', 'Zgodnji sifilis: 70', 'Pozni sifilis: 1', 'Neopredeljeni sifilis: 16', 'Gonoreja: 23', 'Klamidijska okužba: 160'], '2012': ['HIV: 44', 'AIDS: 11', 'Zgodnji sifilis: 54', 'Pozni sifilis: 6', 'Neopredeljeni sifilis: 15', 'Gonoreja: 42', 'Klamidijska okužba: 169'], '2013': ['HIV: 41', 'AIDS: 10', 'Zgodnji sifilis: 32', 'Pozni sifilis: 4', 'Neopredeljeni sifilis: 21', 'Gonoreja: 56', 'Klamidijska okužba: 182'], '2014': ['HIV: 47', 'AIDS: 16', 'Zgodnji sifilis: 17', 'Pozni sifilis: 3', 'Neopredeljeni sifilis: 16', 'Gonoreja: 54', 'Klamidijska okužba: 177'], '2015': ['HIV: 43', 'AIDS: 11', 'Zgodnji sifilis: 39', 'Pozni sifilis: 2', 'Neopredeljeni sifilis: 18', 'Gonoreja: 68', 'Klamidijska okužba: 177'], '2016': ['HIV: 56', 'AIDS: 8', 'Zgodnji sifilis: 38', 'Pozni sifilis: 4', 'Neopredeljeni sifilis: 15', 'Gonoreja: 83', 'Klamidijska okužba: 147'], '2017': ['HIV: 37', 'AIDS: 7', 'Zgodnji sifilis: 45', 'Pozni sifilis: 7', 'Neopredeljeni sifilis: 12', 'Gonoreja: 98', 'Klamidijska okužba: 172']}
spolne_bolezni_zenske =  {'2005': ['HIV: 3', 'AIDS: 2', 'Zgodnji sifilis: 1', 'Pozni sifilis: 2', 'Neopredeljeni sifilis: 2', 'Gonoreja: 15', 'Klamidijska okužba: 127'], '2006': ['HIV: 3', 'AIDS: 0', 'Zgodnji sifilis: 3', 'Pozni sifilis: 4', 'Neopredeljeni sifilis: 6', 'Gonoreja: 2', 'Klamidijska okužba: 53'], '2007': ['HIV: 2', 'AIDS: 2', 'Zgodnji sifilis: 5', 'Pozni sifilis: 2', 'Neopredeljeni sifilis: 1', 'Gonoreja: 4', 'Klamidijska okužba: 56'], '2008': ['HIV: 3', 'AIDS: 2', 'Zgodnji sifilis: 4', 'Pozni sifilis: 5', 'Neopredeljeni sifilis: 4', 'Gonoreja: 2', 'Klamidijska okužba: 36'], '2009': ['HIV: 8', 'AIDS: 2', 'Zgodnji sifilis: 4', 'Pozni sifilis: 2', 'Neopredeljeni sifilis: 6', 'Gonoreja: 5', 'Klamidijska okužba: 31'], '2010': ['HIV: 4', 'AIDS: 0', 'Zgodnji sifilis: 5', 'Pozni sifilis: 6', 'Neopredeljeni sifilis: 3', 'Gonoreja: 2', 'Klamidijska okužba: 61'], '2011': ['HIV: 7', 'AIDS: 3', 'Zgodnji sifilis: 9', 'Pozni sifilis: 4', 'Neopredeljeni sifilis: 11', 'Gonoreja: 2', 'Klamidijska okužba: 71'], '2012': ['HIV: 3', 'AIDS: 1', 'Zgodnji sifilis: 9', 'Pozni sifilis: 2', 'Neopredeljeni sifilis: 4', 'Gonoreja: 3', 'Klamidijska okužba: 80'], '2013': ['HIV: 6', 'AIDS: 1', 'Zgodnji sifilis: 3', 'Pozni sifilis: 1', 'Neopredeljeni sifilis: 4', 'Gonoreja: 6', 'Klamidijska okužba: 66'], '2014': ['HIV: 4', 'AIDS: 1', 'Zgodnji sifilis: 6', 'Pozni sifilis: 1', 'Neopredeljeni sifilis: 5', 'Gonoreja: 7', 'Klamidijska okužba: 93'], '2015': ['HIV: 7', 'AIDS: 0', 'Zgodnji sifilis: 4', 'Pozni sifilis: 0', 'Neopredeljeni sifilis: 5', 'Gonoreja: 5', 'Klamidijska okužba: 71'], '2016': ['HIV: 2', 'AIDS: 2', 'Zgodnji sifilis: 4', 'Pozni sifilis: 0', 'Neopredeljeni sifilis: 5', 'Gonoreja: 9', 'Klamidijska okužba: 99'], '2017': ['HIV: 2', 'AIDS: 0', 'Zgodnji sifilis: 3', 'Pozni sifilis: 1', 'Neopredeljeni sifilis: 2', 'Gonoreja: 15', 'Klamidijska okužba: 94']}


x_os_2 = []  #v tabeli so shranjena leta
hiv = []
for kljuc,vrednost in spolne_bolezni_moski.items():
    x_os_2.append(kljuc)
    hiv.append(vrednost[0])
    hiv_1 = [] #v tabeli shranjeni podatki(samo številke) za moške, ki so okuženi s HIV
    for i in hiv:
        podatek = str(i)
        l = i.split(':')[1]
        st_l = int(l)
        hiv_1.append(st_l)


hiv_z = []
for kljuc,vrednost in spolne_bolezni_zenske.items():
    hiv_z.append(vrednost[0])
    hiv_2 = []  #v tabeli shranjeni podatki(samo številke) za ženske, ki so okužene s HIV
    for i in hiv_z:
        podatek = str(i)
        l = i.split(':')[1]
        st_l = int(l)
        hiv_2.append(st_l)



aids = []
for kljuc,vrednost in spolne_bolezni_moski.items():
    aids.append(vrednost[1])
    aids_1 = []  #v tabeli shranjeni podatki(samo številke) za moške, ki so okuženi z aidsom
    for i in aids:
        podatek = str(i)
        l = i.split(':')[1]
        st_l = int(l)
        aids_1.append(st_l)


aids_z = []
for kljuc,vrednost in spolne_bolezni_zenske.items():
    aids_z.append(vrednost[1])
    aids_2 = []   #v tabeli shranjeni podatki(samo številke) za ženske, ki so okužene z aidsom
    for i in aids_z:
        podatek = str(i)
        l = i.split(':')[1]
        st_l = int(l)
        aids_2.append(st_l)


zg_sifilis = []
for kljuc,vrednost in spolne_bolezni_moski.items():
    zg_sifilis.append(vrednost[2])
    zg_sifilis_1 = []   #v tabeli shranjeni podatki(samo številke) za moške, ki so okuženi z zodnjim sifilisom
    for i in zg_sifilis:
        podatek = str(i)
        l = i.split(':')[1]
        st_l = int(l)
        zg_sifilis_1.append(st_l)

zg_sifilis_z = []
for kljuc,vrednost in spolne_bolezni_zenske.items():
    zg_sifilis_z.append(vrednost[2])
    zg_sifilis_2 = []   #v tabeli shranjeni podatki(samo številke) za ženske, ki so okužene z zgodnjim sifilisom
    for i in zg_sifilis_z:
        podatek = str(i)
        l = i.split(':')[1]
        st_l = int(l)
        zg_sifilis_2.append(st_l)


poz_sifilis = []
for kljuc,vrednost in spolne_bolezni_moski.items():
    poz_sifilis.append(vrednost[3])
    poz_sifilis_1 = []   #v tabeli shranjeni podatki(samo številke) za moške, ki so okuženi s poznim sifilisom
    for i in poz_sifilis:
        podatek = str(i)
        l = i.split(':')[1]
        st_l = int(l)
        poz_sifilis_1.append(st_l)


poz_sifilis_z = []
for kljuc,vrednost in spolne_bolezni_zenske.items():
    poz_sifilis_z.append(vrednost[3])
    poz_sifilis_2 = []   #v tabeli shranjeni podatki(samo številke) za ženske, ki so okužene s poznim sifilisom
    for i in poz_sifilis_z:
        podatek = str(i)
        l = i.split(':')[1]
        st_l = int(l)
        poz_sifilis_2.append(st_l)



neop_sifilis = []
for kljuc,vrednost in spolne_bolezni_moski.items():
    neop_sifilis.append(vrednost[4])
    neop_sifilis_1 = []  #v tabeli shranjeni podatki(samo številke) za moške, ki so okuženi z neopredeljenim sifilisom
    for i in neop_sifilis:
        podatek = str(i)
        l = i.split(':')[1]
        st_l = int(l)
        neop_sifilis_1.append(st_l)

    
neop_sifilis_z = []
for kljuc,vrednost in spolne_bolezni_zenske.items():
    neop_sifilis_z.append(vrednost[4])
    neop_sifilis_2 = []   #v tabeli shranjeni podatki(samo številke) za ženske, ki so okužene z neopredeljenim sifilisom
    for i in neop_sifilis_z:
        podatek = str(i)
        l = i.split(':')[1]
        st_l = int(l)
        neop_sifilis_2.append(st_l)
    
    
gonoreja = []
for kljuc,vrednost in spolne_bolezni_moski.items():
    gonoreja.append(vrednost[5])
    gonoreja_1 = []  #v tabeli shranjeni podatki(samo številke) za moške, ki so okuženi z gonorejo
    for i in gonoreja:
        podatek = str(i)
        l = i.split(':')[1]
        st_l = int(l)
        gonoreja_1.append(st_l)


gonoreja_z = []
for kljuc,vrednost in spolne_bolezni_zenske.items():
    gonoreja_z.append(vrednost[5])
    gonoreja_2 = [] #v tabeli shranjeni podatki(samo številke) za ženske, ki so okužene z gonorejo
    for i in gonoreja_z:
        podatek = str(i)
        l = i.split(':')[1]
        st_l = int(l)
        gonoreja_2.append(st_l)

    
klamidija = []
for kljuc,vrednost in spolne_bolezni_moski.items():
    klamidija.append(vrednost[6])
    klamidija_1 = []  #v tabeli shranjeni podatki(samo številke) za moške, ki so okuženi s klamidijo
    for i in klamidija:
        podatek = str(i)
        l = i.split(':')[1]
        st_l = int(l)
        klamidija_1.append(st_l)


klamidija_z = []
for kljuc,vrednost in spolne_bolezni_zenske.items():
    klamidija_z.append(vrednost[6])
    klamidija_2 = []   #v tabeli shranjeni podatki(samo številke) za ženske, ki so okužene s klamidijo
    for i in klamidija_z:
        podatek = str(i)
        l = i.split(':')[1]
        st_l = int(l)
        klamidija_2.append(st_l)


#########################################################Figure 5#######################################################################################################################
#Tortna grafa, ki predstavljata podatke spolnih bolezni za moške in ženske od leta 2005 do leta 2018
oznake = 'HIV', 'Aids', 'Zgodnji sifilis', 'Pozni sifilis', 'Neopredeljen sifilis', 'Gonoreja', 'Klamidijska okužba' 
velikosti1 = [vsota(hiv_1), vsota(aids_1), vsota(zg_sifilis_1),vsota(poz_sifilis_1), vsota(neop_sifilis_1), vsota(gonoreja_1), vsota(klamidija_1)]
velikosti2 = [vsota(hiv_2), vsota(aids_2), vsota(zg_sifilis_2),vsota(poz_sifilis_2), vsota(neop_sifilis_2), vsota(gonoreja_2), vsota(klamidija_2)]
explode = (0,0,0,0,0,0,0.1)

fig, (ax1, ax2) = plt.subplots(ncols=2, figsize=(8, 4))
ax1.pie(velikosti1, explode=explode, labels=oznake, autopct='%1.1f%%', shadow=True, startangle=90)
ax1.axis('equal') 
ax1.set_title('Graf spolnih bolezni za moške od leta 2005 do leta 2018')
ax2.pie(velikosti2, explode=explode, labels=oznake, autopct='%1.1f%%', shadow=True, startangle=90)
ax2.axis('equal') 
ax2.set_title('Graf spolnih bolezni za ženske od leta 2005 do leta 2018')

plt.show()
#########################################################Figure 6#######################################################################################################################
#Črtna grafa, ki predstavljata klamidijske okužbe za moške in ženske
fig, (ax1,ax2) = plt.subplots(ncols=2, figsize=(8, 4))
ax1.plot(x_os_2, klamidija_1)
ax2.plot(x_os_2, klamidija_2)
ax1.set_title('Graf podatkov klamidijskih okužb za moške')
ax2.set_title('Graf podatkov klamidijskih okužb za ženske')
ax1.set_ylabel('Število moških')
ax1.set_xlabel('Leta')
ax2.set_ylabel('Število žensk')
ax2.set_xlabel('Leta')

plt.show()
#########################################################Datoteka nesreče na delovnem mestu#############################################################################################
# Moški
Na_običajnem_delovnem_mestu = {2008: 13968, 2009: 8640, 2010: 9842, 2011: 9799, 2012: 9351, 2013: 8117, 2014: 6282, 2015: 4370, 2016: 5844, 2017: 8404, 2018: 7698}
Začasno_delovno_mesto_v_isti_enoti = {2008: 662, 2009: 578, 2010: 489, 2011: 414, 2012: 414, 2013: 368, 2014: 405, 2015: 367, 2016: 323, 2017: 386, 2018: 331}
Službena_pot_ali_delovno_mesto_v_drugi_enoti = {2008: 1498, 2009: 1458, 2010: 1355, 2011: 1180, 2012: 1140, 2013: 987, 2014: 1017, 2015: 1213, 2016: 1411, 2017: 1416, 2018: 1023}
Pot_na_delo = {2008: 1005, 2009: 921, 2010: 936, 2011: 694, 2012: 665, 2013: 71, 2014: 45, 2015: 61, 2016: 33, 2017: 41, 2018: 35}
Pot_z_dela = {2008: 732, 2009: 624, 2010: 585, 2011: 440, 2012: 444, 2013: 62, 2014: 53, 2015: 40, 2016: 33, 2017: 37, 2018: 29}

#Ženske = 
Na_običajnem_delovnem_mestu_z = {2008: 4185, 2009: 3590, 2010: 3616, 2011: 2538, 2012: 3110, 2013: 1887, 2014: 1871, 2015: 1964, 2016: 2877, 2017: 3136, 2018: 2269}
Začasno_delovno_mesto_v_isti_enoti_z = {2008: 114, 2009: 100, 2010: 108, 2011: 97, 2012: 91, 2013: 72, 2014: 79, 2015: 81, 2016: 88, 2017: 73, 2018: 65}
Službena_pot_ali_delovno_mesto_v_drugi_enoti_z = {2008: 357, 2009: 367, 2010: 357, 2011: 290, 2012: 254, 2013: 258, 2014: 234, 2015: 256, 2016: 283, 2017: 276, 2018: 252}
Pot_na_delo_z = {2008: 1172, 2009: 1210, 2010: 1352, 2011: 957, 2012: 921, 2013: 63, 2014: 33, 2015: 29, 2016: 36, 2017: 25, 2018: 30}
Pot_z_dela_z = {2008: 817, 2009: 738, 2010: 787, 2011: 655, 2012: 523, 2013: 27, 2014: 28, 2015: 16, 2016: 23, 2017: 20, 2018: 19}


na_ob_d_m = []  #v tabelo shrani podatke o nesrečah na običajnem delovnem mestu za moške
x_os_3 = []
for key, value in Na_običajnem_delovnem_mestu.items():
    x_os_3.append(key)
    na_ob_d_m.append(value)
    
zac_del_m = []   #v tabelo shrani podatke o nesrečah na začasnem delovnem mestu v iski enoti  za moške
for key, value in Začasno_delovno_mesto_v_isti_enoti.items():
    zac_del_m.append(value)

sluz_pot = []     #v tabelo shrani podatke o nesrečah na službeni poti  za moške
for key, value in Službena_pot_ali_delovno_mesto_v_drugi_enoti.items():
    sluz_pot.append(value)

pot_na_delo = []  #v tabelo shrani podatke o nesrečah na poti na delo  za moške
for key, value in Pot_na_delo.items():
    pot_na_delo.append(value)

pot_z_dela = []  #v tabelo shrani podatke o nesrečah na poti z dela za moške
for key, value in Pot_z_dela.items():
    pot_z_dela.append(value)


  
na_ob_d_m_z = []  #v tabelo shrani podatke o nesrečah na običajnem delovnem mestu za ženske
for key, value in Na_običajnem_delovnem_mestu_z.items():
    na_ob_d_m_z.append(value)
    
zac_del_m_z = []  #v tabelo shrani podatke o nesrečah na začasnem delovnem mestu v iski enoti  za ženske
for key, value in Začasno_delovno_mesto_v_isti_enoti_z.items():
    zac_del_m_z.append(value)

sluz_pot_z = []  #v tabelo shrani podatke o nesrečah na službeni poti za ženske
for key, value in Službena_pot_ali_delovno_mesto_v_drugi_enoti_z.items():
    sluz_pot_z.append(value)

pot_na_delo_z = []   #v tabelo shrani podatke o nesrečah na poti na delo za ženske
for key, value in Pot_na_delo_z.items():
    pot_na_delo_z.append(value)

pot_z_dela_z = []   #v tabelo shrani podatke o nesrečah na poti z dela za ženske
for key, value in Pot_z_dela_z.items():
    pot_z_dela_z.append(value)

#########################################################Figure 7#######################################################################################################################
#Štirje tortni diagrami, ki prikazujejo primerjavo podatkov, o nesrečah katerih vzrok je povezan z službo, za ženske in moške

oznake = 'Moški', 'Ženske'
velikosti1 = [vsota(na_ob_d_m),vsota(na_ob_d_m_z)]
velikosti2 = [vsota(sluz_pot), vsota(sluz_pot_z)]
velikost3 = [vsota(pot_na_delo),vsota(pot_na_delo_z)]
velikost4 = [vsota(pot_z_dela),vsota(pot_z_dela_z)]
explode = (0,0)

fig, axs = plt.subplots(2, 2)
ax1 = axs[0, 0]
ax2 = axs[0, 1]
ax3 = axs[1, 0]
ax4 = axs[1, 1]

ax1.pie(velikosti1, explode=explode, labels=oznake, autopct='%1.1f%%', shadow=True, startangle=90)
ax1.axis('equal') 
ax1.set_title('Nesreče na delovnem mestu')
ax2.pie(velikosti2, explode=explode, labels=oznake, autopct='%1.1f%%', shadow=True, startangle=90)
ax2.axis('equal') 
ax2.set_title('Nesreče na službenih poteh')
ax3.pie(velikosti1, explode=explode, labels=oznake, autopct='%1.1f%%', shadow=True, startangle=90)
ax3.axis('equal') 
ax3.set_title('Nesreče na poti v službo')
ax4.pie(velikosti2, explode=explode, labels=oznake, autopct='%1.1f%%', shadow=True, startangle=90)
ax4.axis('equal') 
ax4.set_title('Nesreče na poti iz službe')

plt.show()
####################################################Figure 8###########################################################################################################################
#Pikčasta diagrama, ki prikazuje število nesreč v povezavi z službo, za moške in ženske
x_os_4 = ['Nesreče na \n delovnem \n mestu', 'Nesreče na \n začasnem  \n delovnem \n mestu', 'Nesreče na \n službeni \n poti', 'Nesreče na \n poti na \n delo', 'Nesreče na \n poti \n z dela']
y_os_moski = [vsota(na_ob_d_m), vsota(zac_del_m),vsota(sluz_pot),vsota(pot_na_delo), vsota(pot_z_dela)]
y_os_zenske = [vsota(na_ob_d_m_z), vsota(zac_del_m_z),vsota(sluz_pot_z), vsota(pot_na_delo_z), vsota(pot_z_dela_z)]

fig, (ax1,ax2) = plt.subplots(ncols=2, figsize=(8, 4))
ax1.scatter(x_os_4, y_os_moski)
ax2.scatter(x_os_4, y_os_zenske)
ax1.set_title('Graf podatkov nesreč v povezavi z službo za ženske')
ax2.set_title('Graf podatkov nesreč v povezavi z službo za moške')
ax1.set_ylabel('Število nesreč')
ax1.set_xlabel('Vrste nesreč glede na lokacijo')
ax2.set_ylabel('Število nesreč')
ax2.set_xlabel('Vrste nesreč glede na lokacijo')

plt.show()
##############################################################Datoteka Fetalne smrti##############################################################################
Dovoljeni_splavi = {'2005': {'POMURSKA': '386', 'PODRAVSKA': '1.079', 'KOROŠKA': '187', 'SAVINJSKA': '797', 'ZASAVSKA': '122', 'POSAVSKA': '231', 'JUGOVZHODNA_SLOVENIJA': '371', 'OSREDNJESLOVENJSKA': '1.514', 'GORENJSKA': '548', 'PRIMORSKO_NOTRANJSKA': '143', 'GORIŠKA': '198', 'OBALNO_KRAŠKA': '275'}, '2006': {'POMURSKA': '358', 'PODRAVSKA': '982', 'KOROŠKA': '200', 'SAVINJSKA': '768', 'ZASAVSKA': '117', 'POSAVSKA': '208', 'JUGOVZHODNA_SLOVENIJA': '407', 'OSREDNJESLOVENJSKA': '1.433', 'GORENJSKA': '544', 'PRIMORSKO_NOTRANJSKA': '138', 'GORIŠKA': '198', 'OBALNO_KRAŠKA': '279'}, '2007': {'POMURSKA': '304', 'PODRAVSKA': '984', 'KOROŠKA': '186', 'SAVINJSKA': '685', 'ZASAVSKA': '110', 'POSAVSKA': '169', 'JUGOVZHODNA_SLOVENIJA': '338', 'OSREDNJESLOVENJSKA': '1.367', 'GORENJSKA': '489', 'PRIMORSKO_NOTRANJSKA': '113', 'GORIŠKA': '167', 'OBALNO_KRAŠKA': '264'}, '2008': {'POMURSKA': '309', 'PODRAVSKA': '959', 'KOROŠKA': '143', 'SAVINJSKA': '635', 'ZASAVSKA': '112', 'POSAVSKA': '146', 'JUGOVZHODNA_SLOVENIJA': '383', 'OSREDNJESLOVENJSKA': '1.265', 'GORENJSKA': '488', 'PRIMORSKO_NOTRANJSKA': '109', 'GORIŠKA': '162', 'OBALNO_KRAŠKA': '237'}, '2009': {'POMURSKA': '284', 'PODRAVSKA': '871', 'KOROŠKA': '152', 'SAVINJSKA': '641', 'ZASAVSKA': '109', 'POSAVSKA': '157', 'JUGOVZHODNA_SLOVENIJA': '306', 'OSREDNJESLOVENJSKA': '1.269', 'GORENJSKA': '405', 'PRIMORSKO_NOTRANJSKA': '91', 'GORIŠKA': '144', 'OBALNO_KRAŠKA': '224'}, '2010': {'POMURSKA': '294', 'PODRAVSKA': '766', 'KOROŠKA': '140', 'SAVINJSKA': '554', 'ZASAVSKA': '82', 'POSAVSKA': '162', 'JUGOVZHODNA_SLOVENIJA': '306', 'OSREDNJESLOVENJSKA': '1.159', 'GORENJSKA': '393', 'PRIMORSKO_NOTRANJSKA': '88', 'GORIŠKA': '155', 'OBALNO_KRAŠKA': '229'}, '2011': {'POMURSKA': '265', 'PODRAVSKA': '772', 'KOROŠKA': '140', 'SAVINJSKA': '549', 'ZASAVSKA': '89', 'POSAVSKA': '179', 'JUGOVZHODNA_SLOVENIJA': '287', 'OSREDNJESLOVENJSKA': '1.181', 'GORENJSKA': '359', 'PRIMORSKO_NOTRANJSKA': '85', 'GORIŠKA': '137', 'OBALNO_KRAŠKA': '220'}, '2012': {'POMURSKA': '186', 'PODRAVSKA': '776', 'KOROŠKA': '140', 'SAVINJSKA': '541', 'ZASAVSKA': '75', 'POSAVSKA': '144', 'JUGOVZHODNA_SLOVENIJA': '289', 'OSREDNJESLOVENJSKA': '1.113', 'GORENJSKA': '392', 'PRIMORSKO_NOTRANJSKA': '86', 'GORIŠKA': '136', 'OBALNO_KRAŠKA': '228'}, '2013': {'POMURSKA': '187', 'PODRAVSKA': '818', 'KOROŠKA': '122', 'SAVINJSKA': '532', 'ZASAVSKA': '74', 'POSAVSKA': '160', 'JUGOVZHODNA_SLOVENIJA': '321', 'OSREDNJESLOVENJSKA': '1.017', 'GORENJSKA': '355', 'PRIMORSKO_NOTRANJSKA': '59', 'GORIŠKA': '123', 'OBALNO_KRAŠKA': '243'}, '2014': {'POMURSKA': '213', 'PODRAVSKA': '794', 'KOROŠKA': '111', 'SAVINJSKA': '508', 'ZASAVSKA': '83', 'POSAVSKA': '163', 'JUGOVZHODNA_SLOVENIJA': '308', 'OSREDNJESLOVENJSKA': '1.095', 'GORENJSKA': '362', 'PRIMORSKO_NOTRANJSKA': '69', 'GORIŠKA': '126', 'OBALNO_KRAŠKA': '228'}, '2015': {'POMURSKA': '155', 'PODRAVSKA': '669', 'KOROŠKA': '132', 'SAVINJSKA': '433', 'ZASAVSKA': '95', 'POSAVSKA': '146', 'JUGOVZHODNA_SLOVENIJA': '295', 'OSREDNJESLOVENJSKA': '991', 'GORENJSKA': '373', 'PRIMORSKO_NOTRANJSKA': '55', 'GORIŠKA': '120', 'OBALNO_KRAŠKA': '218'}, '2016': {'POMURSKA': '230', 'PODRAVSKA': '693', 'KOROŠKA': '113', 'SAVINJSKA': '471', 'ZASAVSKA': '84', 'POSAVSKA': '164', 'JUGOVZHODNA_SLOVENIJA': '277', 'OSREDNJESLOVENJSKA': '962', 'GORENJSKA': '329', 'PRIMORSKO_NOTRANJSKA': '62', 'GORIŠKA': '146', 'OBALNO_KRAŠKA': '205'}, '2017': {'POMURSKA': '236', 'PODRAVSKA': '670', 'KOROŠKA': '108', 'SAVINJSKA': '453', 'ZASAVSKA': '113', 'POSAVSKA': '122', 'JUGOVZHODNA_SLOVENIJA': '250', 'OSREDNJESLOVENJSKA': '889', 'GORENJSKA': '321', 'PRIMORSKO_NOTRANJSKA': '67', 'GORIŠKA': '123', 'OBALNO_KRAŠKA': '177'}, '2018': {'POMURSKA': '283', 'PODRAVSKA': '650', 'KOROŠKA': '117', 'SAVINJSKA': '460', 'ZASAVSKA': '93', 'POSAVSKA': '154', 'JUGOVZHODNA_SLOVENIJA': '253', 'OSREDNJESLOVENJSKA': '806', 'GORENJSKA': '302', 'PRIMORSKO_NOTRANJSKA': '50', 'GORIŠKA': '143', 'OBALNO_KRAŠKA': '163'}}
Spontani_splavi =  {'2005': {'POMURSKA': '62', 'PODRAVSKA': '145', 'KOROŠKA': '32', 'SAVINJSKA': '127', 'ZASAVSKA': '18', 'POSAVSKA': '36', 'JUGOVZHODNA_SLOVENIJA': '63', 'OSREDNJESLOVENJSKA': '232', 'GORENJSKA': '115', 'PRIMORSKO_NOTRANJSKA': '22', 'GORIŠKA': '37', 'OBALNO_KRAŠKA': '34'}, '2006': {'POMURSKA': '46', 'PODRAVSKA': '153', 'KOROŠKA': '21', 'SAVINJSKA': '136', 'ZASAVSKA': '28', 'POSAVSKA': '23', 'JUGOVZHODNA_SLOVENIJA': '68', 'OSREDNJESLOVENJSKA': '217', 'GORENJSKA': '92', 'PRIMORSKO_NOTRANJSKA': '31', 'GORIŠKA': '49', 'OBALNO_KRAŠKA': '53'}, '2007': {'POMURSKA': '54', 'PODRAVSKA': '137', 'KOROŠKA': '36', 'SAVINJSKA': '126', 'ZASAVSKA': '16', 'POSAVSKA': '68', 'JUGOVZHODNA_SLOVENIJA': '63', 'OSREDNJESLOVENJSKA': '216', 'GORENJSKA': '112', 'PRIMORSKO_NOTRANJSKA': '29', 'GORIŠKA': '46', 'OBALNO_KRAŠKA': '52'}, '2008': {'POMURSKA': '54', 'PODRAVSKA': '118', 'KOROŠKA': '48', 'SAVINJSKA': '108', 'ZASAVSKA': '12', 'POSAVSKA': '76', 'JUGOVZHODNA_SLOVENIJA': '72', 'OSREDNJESLOVENJSKA': '197', 'GORENJSKA': '101', 'PRIMORSKO_NOTRANJSKA': '26', 'GORIŠKA': '35', 'OBALNO_KRAŠKA': '51'}, '2009': {'POMURSKA': '57', 'PODRAVSKA': '123', 'KOROŠKA': '28', 'SAVINJSKA': '135', 'ZASAVSKA': '21', 'POSAVSKA': '88', 'JUGOVZHODNA_SLOVENIJA': '62', 'OSREDNJESLOVENJSKA': '217', 'GORENJSKA': '72', 'PRIMORSKO_NOTRANJSKA': '21', 'GORIŠKA': '39', 'OBALNO_KRAŠKA': '50'}, '2010': {'POMURSKA': '60', 'PODRAVSKA': '94', 'KOROŠKA': '29', 'SAVINJSKA': '112', 'ZASAVSKA': '15', 'POSAVSKA': '37', 'JUGOVZHODNA_SLOVENIJA': '51', 'OSREDNJESLOVENJSKA': '193', 'GORENJSKA': '54', 'PRIMORSKO_NOTRANJSKA': '21', 'GORIŠKA': '40', 'OBALNO_KRAŠKA': '45'}, '2011': {'POMURSKA': '35', 'PODRAVSKA': '95', 'KOROŠKA': '18', 'SAVINJSKA': '99', 'ZASAVSKA': '16', 'POSAVSKA': '39', 'JUGOVZHODNA_SLOVENIJA': '41', 'OSREDNJESLOVENJSKA': '198', 'GORENJSKA': '52', 'PRIMORSKO_NOTRANJSKA': '28', 'GORIŠKA': '45', 'OBALNO_KRAŠKA': '48'}, '2012': {'POMURSKA': '38', 'PODRAVSKA': '78', 'KOROŠKA': '20', 'SAVINJSKA': '107', 'ZASAVSKA': '8', 'POSAVSKA': '22', 'JUGOVZHODNA_SLOVENIJA': '54', 'OSREDNJESLOVENJSKA': '160', 'GORENJSKA': '63', 'PRIMORSKO_NOTRANJSKA': '14', 'GORIŠKA': '41', 'OBALNO_KRAŠKA': '24'}, '2013': {'POMURSKA': '44', 'PODRAVSKA': '91', 'KOROŠKA': '27', 'SAVINJSKA': '103', 'ZASAVSKA': '8', 'POSAVSKA': '21', 'JUGOVZHODNA_SLOVENIJA': '45', 'OSREDNJESLOVENJSKA': '130', 'GORENJSKA': '39', 'PRIMORSKO_NOTRANJSKA': '15', 'GORIŠKA': '17', 'OBALNO_KRAŠKA': '38'}, '2014': {'POMURSKA': '35', 'PODRAVSKA': '90', 'KOROŠKA': '20', 'SAVINJSKA': '96', 'ZASAVSKA': '13', 'POSAVSKA': '27', 'JUGOVZHODNA_SLOVENIJA': '35', 'OSREDNJESLOVENJSKA': '107', 'GORENJSKA': '48', 'PRIMORSKO_NOTRANJSKA': '15', 'GORIŠKA': '41', 'OBALNO_KRAŠKA': '34'}, '2015': {'POMURSKA': '40', 'PODRAVSKA': '54', 'KOROŠKA': '43', 'SAVINJSKA': '96', 'ZASAVSKA': '19', 'POSAVSKA': '28', 'JUGOVZHODNA_SLOVENIJA': '39', 'OSREDNJESLOVENJSKA': '171', 'GORENJSKA': '44', 'PRIMORSKO_NOTRANJSKA': '15', 'GORIŠKA': '43', 'OBALNO_KRAŠKA': '36'}, '2016': {'POMURSKA': '33', 'PODRAVSKA': '66', 'KOROŠKA': '27', 'SAVINJSKA': '82', 'ZASAVSKA': '9', 'POSAVSKA': '22', 'JUGOVZHODNA_SLOVENIJA': '35', 'OSREDNJESLOVENJSKA': '173', 'GORENJSKA': '39', 'PRIMORSKO_NOTRANJSKA': '22', 'GORIŠKA': '39', 'OBALNO_KRAŠKA': '45'}, '2017': {'POMURSKA': '42', 'PODRAVSKA': '71', 'KOROŠKA': '30', 'SAVINJSKA': '81', 'ZASAVSKA': '7', 'POSAVSKA': '20', 'JUGOVZHODNA_SLOVENIJA': '29', 'OSREDNJESLOVENJSKA': '129', 'GORENJSKA': '66', 'PRIMORSKO_NOTRANJSKA': '14', 'GORIŠKA': '21', 'OBALNO_KRAŠKA': '29'}, '2018': {'POMURSKA': '32', 'PODRAVSKA': '70', 'KOROŠKA': '31', 'SAVINJSKA': '103', 'ZASAVSKA': '9', 'POSAVSKA': '22', 'JUGOVZHODNA_SLOVENIJA': '40', 'OSREDNJESLOVENJSKA': '138', 'GORENJSKA': '57', 'PRIMORSKO_NOTRANJSKA': '25', 'GORIŠKA': '31', 'OBALNO_KRAŠKA': '35'}}
Druge_patološke_nosečnosti = {'2005': {'POMURSKA': '93', 'PODRAVSKA': '255', 'KOROŠKA': '78', 'SAVINJSKA': '229', 'ZASAVSKA': '42', 'POSAVSKA': '57', 'JUGOVZHODNA_SLOVENIJA': '113', 'OSREDNJESLOVENJSKA': '492', 'GORENJSKA': '162', 'PRIMORSKO_NOTRANJSKA': '49', 'GORIŠKA': '95', 'OBALNO_KRAŠKA': '84'}, '2006': {'POMURSKA': '85', 'PODRAVSKA': '300', 'KOROŠKA': '45', 'SAVINJSKA': '249', 'ZASAVSKA': '45', 'POSAVSKA': '46', 'JUGOVZHODNA_SLOVENIJA': '126', 'OSREDNJESLOVENJSKA': '545', 'GORENJSKA': '230', 'PRIMORSKO_NOTRANJSKA': '48', 'GORIŠKA': '112', 'OBALNO_KRAŠKA': '103'}, '2007': {'POMURSKA': '91', 'PODRAVSKA': '318', 'KOROŠKA': '77', 'SAVINJSKA': '277', 'ZASAVSKA': '45', 'POSAVSKA': '79', 'JUGOVZHODNA_SLOVENIJA': '133', 'OSREDNJESLOVENJSKA': '595', 'GORENJSKA': '209', 'PRIMORSKO_NOTRANJSKA': '43', 'GORIŠKA': '139', 'OBALNO_KRAŠKA': '105'}, '2008': {'POMURSKA': '118', 'PODRAVSKA': '260', 'KOROŠKA': '68', 'SAVINJSKA': '305', 'ZASAVSKA': '47', 'POSAVSKA': '65', 'JUGOVZHODNA_SLOVENIJA': '155', 'OSREDNJESLOVENJSKA': '643', 'GORENJSKA': '230', 'PRIMORSKO_NOTRANJSKA': '53', 'GORIŠKA': '133', 'OBALNO_KRAŠKA': '117'}, '2009': {'POMURSKA': '99', 'PODRAVSKA': '331', 'KOROŠKA': '79', 'SAVINJSKA': '265', 'ZASAVSKA': '39', 'POSAVSKA': '93', 'JUGOVZHODNA_SLOVENIJA': '151', 'OSREDNJESLOVENJSKA': '672', 'GORENJSKA': '224', 'PRIMORSKO_NOTRANJSKA': '68', 'GORIŠKA': '133', 'OBALNO_KRAŠKA': '106'}, '2010': {'POMURSKA': '107', 'PODRAVSKA': '289', 'KOROŠKA': '80', 'SAVINJSKA': '248', 'ZASAVSKA': '48', 'POSAVSKA': '68', 'JUGOVZHODNA_SLOVENIJA': '119', 'OSREDNJESLOVENJSKA': '579', 'GORENJSKA': '202', 'PRIMORSKO_NOTRANJSKA': '58', 'GORIŠKA': '118', 'OBALNO_KRAŠKA': '93'}, '2011': {'POMURSKA': '99', 'PODRAVSKA': '254', 'KOROŠKA': '60', 'SAVINJSKA': '270', 'ZASAVSKA': '27', 'POSAVSKA': '70', 'JUGOVZHODNA_SLOVENIJA': '122', 'OSREDNJESLOVENJSKA': '620', 'GORENJSKA': '194', 'PRIMORSKO_NOTRANJSKA': '54', 'GORIŠKA': '107', 'OBALNO_KRAŠKA': '93'}, '2012': {'POMURSKA': '81', 'PODRAVSKA': '288', 'KOROŠKA': '55', 'SAVINJSKA': '256', 'ZASAVSKA': '44', 'POSAVSKA': '86', 'JUGOVZHODNA_SLOVENIJA': '131', 'OSREDNJESLOVENJSKA': '577', 'GORENJSKA': '202', 'PRIMORSKO_NOTRANJSKA': '56', 'GORIŠKA': '125', 'OBALNO_KRAŠKA': '95'}, '2013': {'POMURSKA': '84', 'PODRAVSKA': '302', 'KOROŠKA': '72', 'SAVINJSKA': '230', 'ZASAVSKA': '45', 'POSAVSKA': '74', 'JUGOVZHODNA_SLOVENIJA': '166', 'OSREDNJESLOVENJSKA': '571', 'GORENJSKA': '184', 'PRIMORSKO_NOTRANJSKA': '44', 'GORIŠKA': '104', 'OBALNO_KRAŠKA': '119'}, '2014': {'POMURSKA': '96', 'PODRAVSKA': '284', 'KOROŠKA': '75', 'SAVINJSKA': '263', 'ZASAVSKA': '33', 'POSAVSKA': '69', 'JUGOVZHODNA_SLOVENIJA': '130', 'OSREDNJESLOVENJSKA': '527', 'GORENJSKA': '195', 'PRIMORSKO_NOTRANJSKA': '56', 'GORIŠKA': '90', 'OBALNO_KRAŠKA': '105'}, '2015': {'POMURSKA': '77', 'PODRAVSKA': '288', 'KOROŠKA': '59', 'SAVINJSKA': '219', 'ZASAVSKA': '72', 'POSAVSKA': '65', 'JUGOVZHODNA_SLOVENIJA': '132', 'OSREDNJESLOVENJSKA': '500', 'GORENJSKA': '205', 'PRIMORSKO_NOTRANJSKA': '48', 'GORIŠKA': '110', 'OBALNO_KRAŠKA': '112'}, '2016': {'POMURSKA': '100', 'PODRAVSKA': '306', 'KOROŠKA': '68', 'SAVINJSKA': '251', 'ZASAVSKA': '62', 'POSAVSKA': '67', 'JUGOVZHODNA_SLOVENIJA': '162', 'OSREDNJESLOVENJSKA': '497', 'GORENJSKA': '183', 'PRIMORSKO_NOTRANJSKA': '51', 'GORIŠKA': '108', 'OBALNO_KRAŠKA': '125'}, '2017': {'POMURSKA': '89', 'PODRAVSKA': '281', 'KOROŠKA': '71', 'SAVINJSKA': '264', 'ZASAVSKA': '47', 'POSAVSKA': '77', 'JUGOVZHODNA_SLOVENIJA': '132', 'OSREDNJESLOVENJSKA': '527', 'GORENJSKA': '187', 'PRIMORSKO_NOTRANJSKA': '57', 'GORIŠKA': '115', 'OBALNO_KRAŠKA': '100'}, '2018': {'POMURSKA': '69', 'PODRAVSKA': '275', 'KOROŠKA': '50', 'SAVINJSKA': '234', 'ZASAVSKA': '57', 'POSAVSKA': '66', 'JUGOVZHODNA_SLOVENIJA': '155', 'OSREDNJESLOVENJSKA': '526', 'GORENJSKA': '199', 'PRIMORSKO_NOTRANJSKA': '61', 'GORIŠKA': '103', 'OBALNO_KRAŠKA': '96'}}
Izvenmaternične_nosečnosti =  {'2005': {'POMURSKA': '14', 'PODRAVSKA': '59', 'KOROŠKA': '8', 'SAVINJSKA': '47', 'ZASAVSKA': '1', 'POSAVSKA': '6', 'JUGOVZHODNA_SLOVENIJA': '16', 'OSREDNJESLOVENJSKA': '98', 'GORENJSKA': '36', 'PRIMORSKO_NOTRANJSKA': '13', 'GORIŠKA': '13', 'OBALNO_KRAŠKA': '12'}, '2006': {'POMURSKA': '13', 'PODRAVSKA': '52', 'KOROŠKA': '8', 'SAVINJSKA': '46', 'ZASAVSKA': '9', 'POSAVSKA': '11', 'JUGOVZHODNA_SLOVENIJA': '19', 'OSREDNJESLOVENJSKA': '131', 'GORENJSKA': '36', 'PRIMORSKO_NOTRANJSKA': '11', 'GORIŠKA': '10', 'OBALNO_KRAŠKA': '22'}, '2007': {'POMURSKA': '13', 'PODRAVSKA': '52', 'KOROŠKA': '12', 'SAVINJSKA': '33', 'ZASAVSKA': '4', 'POSAVSKA': '11', 'JUGOVZHODNA_SLOVENIJA': '25', 'OSREDNJESLOVENJSKA': '116', 'GORENJSKA': '33', 'PRIMORSKO_NOTRANJSKA': '8', 'GORIŠKA': '16', 'OBALNO_KRAŠKA': '13'}, '2008': {'POMURSKA': '17', 'PODRAVSKA': '58', 'KOROŠKA': '16', 'SAVINJSKA': '51', 'ZASAVSKA': '5', 'POSAVSKA': '15', 'JUGOVZHODNA_SLOVENIJA': '18', 'OSREDNJESLOVENJSKA': '137', 'GORENJSKA': '19', 'PRIMORSKO_NOTRANJSKA': '15', 'GORIŠKA': '13', 'OBALNO_KRAŠKA': '12'}, '2009': {'POMURSKA': '23', 'PODRAVSKA': '38', 'KOROŠKA': '10', 'SAVINJSKA': '57', 'ZASAVSKA': '6', 'POSAVSKA': '18', 'JUGOVZHODNA_SLOVENIJA': '18', 'OSREDNJESLOVENJSKA': '106', 'GORENJSKA': '39', 'PRIMORSKO_NOTRANJSKA': '5', 'GORIŠKA': '12', 'OBALNO_KRAŠKA': '16'}, '2010': {'POMURSKA': '22', 'PODRAVSKA': '44', 'KOROŠKA': '9', 'SAVINJSKA': '44', 'ZASAVSKA': '10', 'POSAVSKA': '15', 'JUGOVZHODNA_SLOVENIJA': '20', 'OSREDNJESLOVENJSKA': '86', 'GORENJSKA': '26', 'PRIMORSKO_NOTRANJSKA': '11', 'GORIŠKA': '14', 'OBALNO_KRAŠKA': '20'}, '2011': {'POMURSKA': '8', 'PODRAVSKA': '49', 'KOROŠKA': '16', 'SAVINJSKA': '48', 'ZASAVSKA': '3', 'POSAVSKA': '10', 'JUGOVZHODNA_SLOVENIJA': '23', 'OSREDNJESLOVENJSKA': '108', 'GORENJSKA': '27', 'PRIMORSKO_NOTRANJSKA': '13', 'GORIŠKA': '9', 'OBALNO_KRAŠKA': '30'}, '2012': {'POMURSKA': '10', 'PODRAVSKA': '63', 'KOROŠKA': '17', 'SAVINJSKA': '44', 'ZASAVSKA': '6', 'POSAVSKA': '14', 'JUGOVZHODNA_SLOVENIJA': '26', 'OSREDNJESLOVENJSKA': '126', 'GORENJSKA': '45', 'PRIMORSKO_NOTRANJSKA': '10', 'GORIŠKA': '14', 'OBALNO_KRAŠKA': '20'}, '2013': {'POMURSKA': '25', 'PODRAVSKA': '56', 'KOROŠKA': '14', 'SAVINJSKA': '46', 'ZASAVSKA': '6', 'POSAVSKA': '19', 'JUGOVZHODNA_SLOVENIJA': '18', 'OSREDNJESLOVENJSKA': '89', 'GORENJSKA': '33', 'PRIMORSKO_NOTRANJSKA': '5', 'GORIŠKA': '13', 'OBALNO_KRAŠKA': '18'}, '2014': {'POMURSKA': '12', 'PODRAVSKA': '63', 'KOROŠKA': '12', 'SAVINJSKA': '50', 'ZASAVSKA': '7', 'POSAVSKA': '11', 'JUGOVZHODNA_SLOVENIJA': '13', 'OSREDNJESLOVENJSKA': '95', 'GORENJSKA': '28', 'PRIMORSKO_NOTRANJSKA': '5', 'GORIŠKA': '18', 'OBALNO_KRAŠKA': '16'}, '2015': {'POMURSKA': '16', 'PODRAVSKA': '65', 'KOROŠKA': '16', 'SAVINJSKA': '43', 'ZASAVSKA': '13', 'POSAVSKA': '15', 'JUGOVZHODNA_SLOVENIJA': '16', 'OSREDNJESLOVENJSKA': '77', 'GORENJSKA': '21', 'PRIMORSKO_NOTRANJSKA': '10', 'GORIŠKA': '18', 'OBALNO_KRAŠKA': '11'}, '2016': {'POMURSKA': '15', 'PODRAVSKA': '41', 'KOROŠKA': '5', 'SAVINJSKA': '41', 'ZASAVSKA': '10', 'POSAVSKA': '12', 'JUGOVZHODNA_SLOVENIJA': '20', 'OSREDNJESLOVENJSKA': '85', 'GORENJSKA': '24', 'PRIMORSKO_NOTRANJSKA': '7', 'GORIŠKA': '12', 'OBALNO_KRAŠKA': '18'}, '2017': {'POMURSKA': '12', 'PODRAVSKA': '47', 'KOROŠKA': '11', 'SAVINJSKA': '39', 'ZASAVSKA': '6', 'POSAVSKA': '22', 'JUGOVZHODNA_SLOVENIJA': '23', 'OSREDNJESLOVENJSKA': '63', 'GORENJSKA': '24', 'PRIMORSKO_NOTRANJSKA': '8', 'GORIŠKA': '6', 'OBALNO_KRAŠKA': '27'}, '2018': {'POMURSKA': '16', 'PODRAVSKA': '54', 'KOROŠKA': '10', 'SAVINJSKA': '45', 'ZASAVSKA': '10', 'POSAVSKA': '12', 'JUGOVZHODNA_SLOVENIJA': '21', 'OSREDNJESLOVENJSKA': '75', 'GORENJSKA': '31', 'PRIMORSKO_NOTRANJSKA': '15', 'GORIŠKA': '14', 'OBALNO_KRAŠKA': '16'}}

#Dovoljeni splavi
pomurska = []
podravska = []
koroska = []
savinjska = []
zasavska = []
posavska = []
jv_slo = []
osr_slo = []
gorenjska = []
prim_notranjska = []
goriska = []
obalno_kraska = []
for key, value in Dovoljeni_splavi.items():
    for kljuc,vrednost in value.items():
        if kljuc == 'POMURSKA':
            pomurska.append(float(value['POMURSKA']))
        if kljuc == 'PODRAVSKA':
            podravska.append(float(value['PODRAVSKA']))
        if kljuc == 'KOROŠKA':
            koroska.append(float(value['KOROŠKA']))
        if kljuc == 'SAVINJSKA':
            savinjska.append(float(value['SAVINJSKA']))
        if kljuc == 'ZASAVSKA':
            zasavska.append(float(value['ZASAVSKA']))
        if kljuc == 'POSAVSKA':
            posavska.append(float(value['POSAVSKA']))
        if kljuc == 'JUGOVZHODNA_SLOVENIJA':
            jv_slo.append(float(value['JUGOVZHODNA_SLOVENIJA']))
        if kljuc == 'OSREDNJESLOVENJSKA':
            osr_slo.append(float(value['OSREDNJESLOVENJSKA']))
        if kljuc == 'GORENJSKA':
            gorenjska.append(float(value['GORENJSKA']))
        if kljuc == 'PRIMORSKO_NOTRANJSKA':
            prim_notranjska.append(float(value['PRIMORSKO_NOTRANJSKA']))
        if kljuc == 'GORIŠKA':
            goriska.append(value['GORIŠKA'])
        if kljuc == 'OBALNO_KRAŠKA':
            obalno_kraska.append(float(value['OBALNO_KRAŠKA']))


#Spontani splavi
pomurska1 = []
podravska1 = []
koroska1 = []
savinjska1 = []
zasavska1 = []
posavska1 = []
jv_slo1 = []
osr_slo1 = []
gorenjska1 = []
prim_notranjska1 = []
goriska1 = []
obalno_kraska1= []
for key, value in Spontani_splavi.items():
    for kljuc,vrednost in value.items():
        if kljuc == 'POMURSKA':
            pomurska1.append(float(value['POMURSKA']))
        if kljuc == 'PODRAVSKA':
            podravska1.append(float(value['PODRAVSKA']))
        if kljuc == 'KOROŠKA':
            koroska1.append(float(value['KOROŠKA']))
        if kljuc == 'SAVINJSKA':
            savinjska1.append(float(value['SAVINJSKA']))
        if kljuc == 'ZASAVSKA':
            zasavska1.append(float(value['ZASAVSKA']))
        if kljuc == 'POSAVSKA':
            posavska1.append(float(value['POSAVSKA']))
        if kljuc == 'JUGOVZHODNA_SLOVENIJA':
            jv_slo1.append(float(value['JUGOVZHODNA_SLOVENIJA']))
        if kljuc == 'OSREDNJESLOVENJSKA':
            osr_slo1.append(float(value['OSREDNJESLOVENJSKA']))
        if kljuc == 'GORENJSKA':
            gorenjska1.append(float(value['GORENJSKA']))
        if kljuc == 'PRIMORSKO_NOTRANJSKA':
            prim_notranjska1.append(float(value['PRIMORSKO_NOTRANJSKA']))
        if kljuc == 'GORIŠKA':
            goriska1.append(value['GORIŠKA'])
        if kljuc == 'OBALNO_KRAŠKA':
            obalno_kraska1.append(float(value['OBALNO_KRAŠKA']))

#Druge patološke nosečnosti            
pomurska2 = []
podravska2 = []
koroska2 = []
savinjska2 = []
zasavska2 = []
posavska2 = []
jv_slo2 = []
osr_slo2 = []
gorenjska2 = []
prim_notranjska2 = []
goriska2 = []
obalno_kraska2 = []
for key, value in Druge_patološke_nosečnosti.items():
    for kljuc,vrednost in value.items():
        if kljuc == 'POMURSKA':
            pomurska2.append(float(value['POMURSKA']))
        if kljuc == 'PODRAVSKA':
            podravska2.append(float(value['PODRAVSKA']))
        if kljuc == 'KOROŠKA':
            koroska2.append(float(value['KOROŠKA']))
        if kljuc == 'SAVINJSKA':
            savinjska2.append(float(value['SAVINJSKA']))
        if kljuc == 'ZASAVSKA':
            zasavska2.append(float(value['ZASAVSKA']))
        if kljuc == 'POSAVSKA':
            posavska2.append(float(value['POSAVSKA']))
        if kljuc == 'JUGOVZHODNA_SLOVENIJA':
            jv_slo2.append(float(value['JUGOVZHODNA_SLOVENIJA']))
        if kljuc == 'OSREDNJESLOVENJSKA':
            osr_slo2.append(float(value['OSREDNJESLOVENJSKA']))
        if kljuc == 'GORENJSKA':
            gorenjska2.append(float(value['GORENJSKA']))
        if kljuc == 'PRIMORSKO_NOTRANJSKA':
            prim_notranjska2.append(float(value['PRIMORSKO_NOTRANJSKA']))
        if kljuc == 'GORIŠKA':
            goriska2.append(value['GORIŠKA'])
        if kljuc == 'OBALNO_KRAŠKA':
            obalno_kraska2.append(float(value['OBALNO_KRAŠKA']))            
            
#Izvenmaternične nosečnosti
pomurska3 = []
podravska3 = []
koroska3 = []
savinjska3 = []
zasavska3 = []
posavska3 = []
jv_slo3 = []
osr_slo3 = []
gorenjska3 = []
prim_notranjska3 = []
goriska3 = []
obalno_kraska3 = []
for key, value in Izvenmaternične_nosečnosti.items():
    for kljuc,vrednost in value.items():
        if kljuc == 'POMURSKA':
            pomurska3.append(float(value['POMURSKA']))
        if kljuc == 'PODRAVSKA':
            podravska3.append(float(value['PODRAVSKA']))
        if kljuc == 'KOROŠKA':
            koroska3.append(float(value['KOROŠKA']))
        if kljuc == 'SAVINJSKA':
            savinjska3.append(float(value['SAVINJSKA']))
        if kljuc == 'ZASAVSKA':
            zasavska3.append(float(value['ZASAVSKA']))
        if kljuc == 'POSAVSKA':
            posavska3.append(float(value['POSAVSKA']))
        if kljuc == 'JUGOVZHODNA_SLOVENIJA':
            jv_slo3.append(float(value['JUGOVZHODNA_SLOVENIJA']))
        if kljuc == 'OSREDNJESLOVENJSKA':
            osr_slo3.append(float(value['OSREDNJESLOVENJSKA']))
        if kljuc == 'GORENJSKA':
            gorenjska3.append(float(value['GORENJSKA']))
        if kljuc == 'PRIMORSKO_NOTRANJSKA':
            prim_notranjska3.append(float(value['PRIMORSKO_NOTRANJSKA']))
        if kljuc == 'GORIŠKA':
            goriska3.append(value['GORIŠKA'])
        if kljuc == 'OBALNO_KRAŠKA':
            obalno_kraska3.append(float(value['OBALNO_KRAŠKA']))            
            
########################################################################Figure 9#######################################################################################################
#Stolpični diagram, ki predstavlja število dovoljenih splavov od leta 2005 do leta 2018 za posamezno regijo
            
x_os_5 = ['Pomurska', 'Podravska','Koroška', 'Savinjska', 'Zasavska', 'Posavska', "Jugovzhodna \n  Slovenija", 'Osrednja \n Slovenija', 'Gorenjska', 'Primorsko- \n notranjska', 'Goriška', 'Obalno- \n kraška']
dovoljeni_splavi = [vsota(pomurska), vsota(podravska), vsota(koroska), vsota(savinjska), vsota(zasavska), vsota(posavska),vsota(jv_slo), vsota(osr_slo), vsota(gorenjska), vsota(prim_notranjska),vsota(goriska),vsota(obalno_kraska)]
fig, ax = plt.subplots(figsize=(8, 4))
ax.bar(x_os_5, dovoljeni_splavi,color='r')
ax.set_title('Graf podatkov o dovoljenih splavih',color='r')
ax.set_ylabel('Število žensk')
ax.set_xlabel('Regije v Sloveniji')

plt.show()
#########################################################################Figure 10#######################################################################################################
#Stolpični diagram, ki predstavlja število spontanih splavov od leta 2005 do leta 2018 za posamezno regijo

spontani_splavi = [vsota(pomurska1), vsota(podravska1), vsota(koroska1), vsota(savinjska1), vsota(zasavska1), vsota(posavska1),vsota(jv_slo1), vsota(osr_slo1), vsota(gorenjska1), vsota(prim_notranjska1),vsota(goriska1),vsota(obalno_kraska1)]
fig, ax = plt.subplots(figsize=(8, 4))
ax.bar(x_os_5, spontani_splavi)
ax.set_title('Graf podatkov o spontanih splavih',color='b')
ax.set_ylabel('Število žensk')
ax.set_xlabel('Regije v Sloveniji')

plt.show()
#########################################################################Figure 11#######################################################################################################
#Stolpični diagram, ki predstavlja število drugih patoloških nosenosti od leta 2005 do leta 2018 za posamezno regijo

druge_patoloske_nosecnosti = [vsota(pomurska2), vsota(podravska2), vsota(koroska2), vsota(savinjska2), vsota(zasavska2), vsota(posavska2),vsota(jv_slo2), vsota(osr_slo2), vsota(gorenjska2), vsota(prim_notranjska2),vsota(goriska2),vsota(obalno_kraska2)]
fig, ax = plt.subplots(figsize=(8, 4))
ax.bar(x_os_5, druge_patoloske_nosecnosti, color='g')
ax.set_title('Graf podatkov o drugih patoloških nosečnostih', color='g')
ax.set_ylabel('Število žensk')
ax.set_xlabel('Regije v Sloveniji')

plt.show()
#########################################################################Figure 12######################################################################################################
#Stolpični diagram, ki predstavlja število izvenmaterničnih nosečnosti od leta 2005 do leta 2018 za posamezno regijo

izvenmaternicne_nosecnosti = [vsota(pomurska3), vsota(podravska3), vsota(koroska3), vsota(savinjska3), vsota(zasavska3), vsota(posavska3),vsota(jv_slo3), vsota(osr_slo3), vsota(gorenjska3), vsota(prim_notranjska3),vsota(goriska3),vsota(obalno_kraska3)]
fig, ax = plt.subplots(figsize=(8, 4))
ax.bar(x_os_5, izvenmaternicne_nosecnosti, color='y')
ax.set_title('Graf podatkov o izvenmaterničnih nosečnostih', color='y')
ax.set_ylabel('Število žensk')
ax.set_xlabel('Regije v Sloveniji')

plt.show()






    


























