############################Analiza podatkov###################################
import re

# pokrajina z največjim številom spontanih splavov ter izvenmaterničnih nosečnosti
spontani_splavi = {'2005': ['POMURSKA: 62', 'PODRAVSKA: 145', 'KOROŠKA: 32', 'SAVINJSKA: 127', 'ZASAVSKA: 18', 'POSAVSKA: 36', 'JUGOVZHODNA_SLOVENIJA: 63', 'OSREDNJESLOVENJSKA: 232', 'GORENJSKA: 115', 'PRIMORSKO_NOTRANJSKA: 22', 'GORIŠKA: 37', 'OBALNO_KRAŠKA: 34'], '2006': ['POMURSKA: 46', 'PODRAVSKA: 153', 'KOROŠKA: 21', 'SAVINJSKA: 136', 'ZASAVSKA: 28', 'POSAVSKA: 23', 'JUGOVZHODNA_SLOVENIJA: 68', 'OSREDNJESLOVENJSKA: 217', 'GORENJSKA: 92', 'PRIMORSKO_NOTRANJSKA: 31', 'GORIŠKA: 49', 'OBALNO_KRAŠKA: 53'], '2007': ['POMURSKA: 54', 'PODRAVSKA: 137', 'KOROŠKA: 36', 'SAVINJSKA: 126', 'ZASAVSKA: 16', 'POSAVSKA: 68', 'JUGOVZHODNA_SLOVENIJA: 63', 'OSREDNJESLOVENJSKA: 216', 'GORENJSKA: 112', 'PRIMORSKO_NOTRANJSKA: 29', 'GORIŠKA: 46', 'OBALNO_KRAŠKA: 52'], '2008': ['POMURSKA: 54', 'PODRAVSKA: 118', 'KOROŠKA: 48', 'SAVINJSKA: 108', 'ZASAVSKA: 12', 'POSAVSKA: 76', 'JUGOVZHODNA_SLOVENIJA: 72', 'OSREDNJESLOVENJSKA: 197', 'GORENJSKA: 101', 'PRIMORSKO_NOTRANJSKA: 26', 'GORIŠKA: 35', 'OBALNO_KRAŠKA: 51'], '2009': ['POMURSKA: 57', 'PODRAVSKA: 123', 'KOROŠKA: 28', 'SAVINJSKA: 135', 'ZASAVSKA: 21', 'POSAVSKA: 88', 'JUGOVZHODNA_SLOVENIJA: 62', 'OSREDNJESLOVENJSKA: 217', 'GORENJSKA: 72', 'PRIMORSKO_NOTRANJSKA: 21', 'GORIŠKA: 39', 'OBALNO_KRAŠKA: 50'], '2010': ['POMURSKA: 60', 'PODRAVSKA: 94', 'KOROŠKA: 29', 'SAVINJSKA: 112', 'ZASAVSKA: 15', 'POSAVSKA: 37', 'JUGOVZHODNA_SLOVENIJA: 51', 'OSREDNJESLOVENJSKA: 193', 'GORENJSKA: 54', 'PRIMORSKO_NOTRANJSKA: 21', 'GORIŠKA: 40', 'OBALNO_KRAŠKA: 45'], '2011': ['POMURSKA: 35', 'PODRAVSKA: 95', 'KOROŠKA: 18', 'SAVINJSKA: 99', 'ZASAVSKA: 16', 'POSAVSKA: 39', 'JUGOVZHODNA_SLOVENIJA: 41', 'OSREDNJESLOVENJSKA: 198', 'GORENJSKA: 52', 'PRIMORSKO_NOTRANJSKA: 28', 'GORIŠKA: 45', 'OBALNO_KRAŠKA: 48'], '2012': ['POMURSKA: 38', 'PODRAVSKA: 78', 'KOROŠKA: 20', 'SAVINJSKA: 107', 'ZASAVSKA: 8', 'POSAVSKA: 22', 'JUGOVZHODNA_SLOVENIJA: 54', 'OSREDNJESLOVENJSKA: 160', 'GORENJSKA: 63', 'PRIMORSKO_NOTRANJSKA: 14', 'GORIŠKA: 41', 'OBALNO_KRAŠKA: 24'], '2013': ['POMURSKA: 44', 'PODRAVSKA: 91', 'KOROŠKA: 27', 'SAVINJSKA: 103', 'ZASAVSKA: 8', 'POSAVSKA: 21', 'JUGOVZHODNA_SLOVENIJA: 45', 'OSREDNJESLOVENJSKA: 130', 'GORENJSKA: 39', 'PRIMORSKO_NOTRANJSKA: 15', 'GORIŠKA: 17', 'OBALNO_KRAŠKA: 38'], '2014': ['POMURSKA: 35', 'PODRAVSKA: 90', 'KOROŠKA: 20', 'SAVINJSKA: 96', 'ZASAVSKA: 13', 'POSAVSKA: 27', 'JUGOVZHODNA_SLOVENIJA: 35', 'OSREDNJESLOVENJSKA: 107', 'GORENJSKA: 48', 'PRIMORSKO_NOTRANJSKA: 15', 'GORIŠKA: 41', 'OBALNO_KRAŠKA: 34'], '2015': ['POMURSKA: 40', 'PODRAVSKA: 54', 'KOROŠKA: 43', 'SAVINJSKA: 96', 'ZASAVSKA: 19', 'POSAVSKA: 28', 'JUGOVZHODNA_SLOVENIJA: 39', 'OSREDNJESLOVENJSKA: 171', 'GORENJSKA: 44', 'PRIMORSKO_NOTRANJSKA: 15', 'GORIŠKA: 43', 'OBALNO_KRAŠKA: 36'], '2016': ['POMURSKA: 33', 'PODRAVSKA: 66', 'KOROŠKA: 27', 'SAVINJSKA: 82', 'ZASAVSKA: 9', 'POSAVSKA: 22', 'JUGOVZHODNA_SLOVENIJA: 35', 'OSREDNJESLOVENJSKA: 173', 'GORENJSKA: 39', 'PRIMORSKO_NOTRANJSKA: 22', 'GORIŠKA: 39', 'OBALNO_KRAŠKA: 45'], '2017': ['POMURSKA: 42', 'PODRAVSKA: 71', 'KOROŠKA: 30', 'SAVINJSKA: 81', 'ZASAVSKA: 7', 'POSAVSKA: 20', 'JUGOVZHODNA_SLOVENIJA: 29', 'OSREDNJESLOVENJSKA: 129', 'GORENJSKA: 66', 'PRIMORSKO_NOTRANJSKA: 14', 'GORIŠKA: 21', 'OBALNO_KRAŠKA: 29'], '2018': ['POMURSKA: 32', 'PODRAVSKA: 70', 'KOROŠKA: 31', 'SAVINJSKA: 103', 'ZASAVSKA: 9', 'POSAVSKA: 22', 'JUGOVZHODNA_SLOVENIJA: 40', 'OSREDNJESLOVENJSKA: 138', 'GORENJSKA: 57', 'PRIMORSKO_NOTRANJSKA: 25', 'GORIŠKA: 31', 'OBALNO_KRAŠKA: 35']}
izvenmaternicne_nosecnosti = {'2005': ['POMURSKA: 14', 'PODRAVSKA: 59', 'KOROŠKA: 8', 'SAVINJSKA: 47', 'ZASAVSKA: 1', 'POSAVSKA: 6', 'JUGOVZHODNA_SLOVENIJA: 16', 'OSREDNJESLOVENJSKA: 98', 'GORENJSKA: 36', 'PRIMORSKO_NOTRANJSKA: 13', 'GORIŠKA: 13', 'OBALNO_KRAŠKA: 12'], '2006': ['POMURSKA: 13', 'PODRAVSKA: 52', 'KOROŠKA: 8', 'SAVINJSKA: 46', 'ZASAVSKA: 9', 'POSAVSKA: 11', 'JUGOVZHODNA_SLOVENIJA: 19', 'OSREDNJESLOVENJSKA: 131', 'GORENJSKA: 36', 'PRIMORSKO_NOTRANJSKA: 11', 'GORIŠKA: 10', 'OBALNO_KRAŠKA: 22'], '2007': ['POMURSKA: 13', 'PODRAVSKA: 52', 'KOROŠKA: 12', 'SAVINJSKA: 33', 'ZASAVSKA: 4', 'POSAVSKA: 11', 'JUGOVZHODNA_SLOVENIJA: 25', 'OSREDNJESLOVENJSKA: 116', 'GORENJSKA: 33', 'PRIMORSKO_NOTRANJSKA: 8', 'GORIŠKA: 16', 'OBALNO_KRAŠKA: 13'], '2008': ['POMURSKA: 17', 'PODRAVSKA: 58', 'KOROŠKA: 16', 'SAVINJSKA: 51', 'ZASAVSKA: 5', 'POSAVSKA: 15', 'JUGOVZHODNA_SLOVENIJA: 18', 'OSREDNJESLOVENJSKA: 137', 'GORENJSKA: 19', 'PRIMORSKO_NOTRANJSKA: 15', 'GORIŠKA: 13', 'OBALNO_KRAŠKA: 12'], '2009': ['POMURSKA: 23', 'PODRAVSKA: 38', 'KOROŠKA: 10', 'SAVINJSKA: 57', 'ZASAVSKA: 6', 'POSAVSKA: 18', 'JUGOVZHODNA_SLOVENIJA: 18', 'OSREDNJESLOVENJSKA: 106', 'GORENJSKA: 39', 'PRIMORSKO_NOTRANJSKA: 5', 'GORIŠKA: 12', 'OBALNO_KRAŠKA: 16'], '2010': ['POMURSKA: 22', 'PODRAVSKA: 44', 'KOROŠKA: 9', 'SAVINJSKA: 44', 'ZASAVSKA: 10', 'POSAVSKA: 15', 'JUGOVZHODNA_SLOVENIJA: 20', 'OSREDNJESLOVENJSKA: 86', 'GORENJSKA: 26', 'PRIMORSKO_NOTRANJSKA: 11', 'GORIŠKA: 14', 'OBALNO_KRAŠKA: 20'], '2011': ['POMURSKA: 8', 'PODRAVSKA: 49', 'KOROŠKA: 16', 'SAVINJSKA: 48', 'ZASAVSKA: 3', 'POSAVSKA: 10', 'JUGOVZHODNA_SLOVENIJA: 23', 'OSREDNJESLOVENJSKA: 108', 'GORENJSKA: 27', 'PRIMORSKO_NOTRANJSKA: 13', 'GORIŠKA: 9', 'OBALNO_KRAŠKA: 30'], '2012': ['POMURSKA: 10', 'PODRAVSKA: 63', 'KOROŠKA: 17', 'SAVINJSKA: 44', 'ZASAVSKA: 6', 'POSAVSKA: 14', 'JUGOVZHODNA_SLOVENIJA: 26', 'OSREDNJESLOVENJSKA: 126', 'GORENJSKA: 45', 'PRIMORSKO_NOTRANJSKA: 10', 'GORIŠKA: 14', 'OBALNO_KRAŠKA: 20'], '2013': ['POMURSKA: 25', 'PODRAVSKA: 56', 'KOROŠKA: 14', 'SAVINJSKA: 46', 'ZASAVSKA: 6', 'POSAVSKA: 19', 'JUGOVZHODNA_SLOVENIJA: 18', 'OSREDNJESLOVENJSKA: 89', 'GORENJSKA: 33', 'PRIMORSKO_NOTRANJSKA: 5', 'GORIŠKA: 13', 'OBALNO_KRAŠKA: 18'], '2014': ['POMURSKA: 12', 'PODRAVSKA: 63', 'KOROŠKA: 12', 'SAVINJSKA: 50', 'ZASAVSKA: 7', 'POSAVSKA: 11', 'JUGOVZHODNA_SLOVENIJA: 13', 'OSREDNJESLOVENJSKA: 95', 'GORENJSKA: 28', 'PRIMORSKO_NOTRANJSKA: 5', 'GORIŠKA: 18', 'OBALNO_KRAŠKA: 16'], '2015': ['POMURSKA: 16', 'PODRAVSKA: 65', 'KOROŠKA: 16', 'SAVINJSKA: 43', 'ZASAVSKA: 13', 'POSAVSKA: 15', 'JUGOVZHODNA_SLOVENIJA: 16', 'OSREDNJESLOVENJSKA: 77', 'GORENJSKA: 21', 'PRIMORSKO_NOTRANJSKA: 10', 'GORIŠKA: 18', 'OBALNO_KRAŠKA: 11'], '2016': ['POMURSKA: 15', 'PODRAVSKA: 41', 'KOROŠKA: 5', 'SAVINJSKA: 41', 'ZASAVSKA: 10', 'POSAVSKA: 12', 'JUGOVZHODNA_SLOVENIJA: 20', 'OSREDNJESLOVENJSKA: 85', 'GORENJSKA: 24', 'PRIMORSKO_NOTRANJSKA: 7', 'GORIŠKA: 12', 'OBALNO_KRAŠKA: 18'], '2017': ['POMURSKA: 12', 'PODRAVSKA: 47', 'KOROŠKA: 11', 'SAVINJSKA: 39', 'ZASAVSKA: 6', 'POSAVSKA: 22', 'JUGOVZHODNA_SLOVENIJA: 23', 'OSREDNJESLOVENJSKA: 63', 'GORENJSKA: 24', 'PRIMORSKO_NOTRANJSKA: 8', 'GORIŠKA: 6', 'OBALNO_KRAŠKA: 27'], '2018': ['POMURSKA: 16', 'PODRAVSKA: 54', 'KOROŠKA: 10', 'SAVINJSKA: 45', 'ZASAVSKA: 10', 'POSAVSKA: 12', 'JUGOVZHODNA_SLOVENIJA: 21', 'OSREDNJESLOVENJSKA: 75', 'GORENJSKA: 31', 'PRIMORSKO_NOTRANJSKA: 15', 'GORIŠKA: 14', 'OBALNO_KRAŠKA: 16']}

slovar_vsot = dict()
for leto in spontani_splavi.keys():
    for niz in spontani_splavi[leto]:
        pokrajina, stevilo = re.split(r': ', niz)
        if pokrajina not in slovar_vsot.keys():
            slovar_vsot[pokrajina] = 0
        slovar_vsot[pokrajina] += int(stevilo)
najvec = 0
for pokrajina in slovar_vsot:
    if slovar_vsot[pokrajina] > najvec:
        najvec = slovar_vsot[pokrajina]

for kljuc, vrednost in slovar_vsot.items():
    if vrednost == najvec:
        print('Pokrajina z največjim številom spontanih splavov: ', kljuc)

slovar_vsot2 = dict()
for leto in izvenmaternicne_nosecnosti.keys():
    for niz in izvenmaternicne_nosecnosti[leto]:
        pokrajina, stevilo = re.split(r': ', niz)
        if pokrajina not in slovar_vsot2.keys():
            slovar_vsot2[pokrajina] = 0
        slovar_vsot2[pokrajina] += int(stevilo)
najvec = 0
for pokrajina in slovar_vsot2:
    if slovar_vsot2[pokrajina] > najvec:
        najvec = slovar_vsot2[pokrajina]

for kljuc, vrednost in slovar_vsot2.items():
    if vrednost == najvec:
        print('Pokrajina z največjim številom izvenmaterničnih nosečnosti: ', kljuc)

print('')
# razlika povprečne življenske dobe v letih od leta 2005 do 2018

slovar_moski = {'Ob rojstvu': ['73,9', '74,5', '74,6', '75,5', '75,9', '76,4', '76,8', '77,1', '77,2', '78,2', '77,8', '78,2', '78,2', '78,5'], '50 let': ['26,8', '27,2', '27,4', '28', '28,2', '28,5', '28,9', '29', '29,2', '29,9', '29,7', '30', '29,8', '30,2'], '65 let': ['15,2', '15,8', '15,9', '16,4', '16,4', '16,8', '16,9', '17,1', '17,2', '17,7', '17,6', '17,9', '17,6', '17,8']}
slovar_zenske = {'Ob rojstvu': ['80,9', '82', '82', '82,6', '82,7', '83,1', '83,3', '83,3', '83,6', '84,1', '83,9', '84,3', '84', '84,4'], '50 let': ['32,4', '33,2', '33,4', '33,8', '33,8', '34,4', '34,5', '34,3', '34,8', '35,1', '34,9', '35,3', '35,1', '35,2'], '65 let': ['19,3', '20', '20,2', '20,5', '20,5', '21', '21,1', '21,1', '21,4', '21,6', '21,4', '21,8', '21,7', '21,8']}

def razlika_v_letih(slovar):
    s = dict()
    for kljuc in slovar:
        zadnji = slovar[kljuc][-1]
        prvi = slovar[kljuc][0]
        if len(zadnji.split(',')) == 1:
            # celo število
            st = int(zadnji)
        elif len(zadnji.split(',')) == 2:
            tab = zadnji.split(',')
            st = float(tab[0] + '.' + tab[1])
        
        if len(prvi.split(',')) == 1:
            st1 = int(prvi)
        elif len(prvi.split(',')) == 2:
            tab = prvi.split(',')
            st1 = float(tab[0] + '.' + tab[1])
        s[kljuc] = round(st - st1, 3)  # zaokroži na 3 mesta natančno
    return s

decki = razlika_v_letih(slovar_moski)
deklice = razlika_v_letih(slovar_zenske)
print('V 14tih letih se je življenkska doba moških ob rojstvu podaljšala za {}, po 50tih letih za {} in po 65tih letih za {} let.'.format(decki['Ob rojstvu'], decki['50 let'], decki['65 let']))
print('V 14tih letih se je življenkska doba žensk ob rojstvu podaljšala za {}, po 50tih letih za {} in po 65tih letih za {} let.'.format(deklice['Ob rojstvu'], deklice['50 let'], deklice['65 let']))     
print('')

# računanje naravnega prirastka
decki_rojstva = {2005: '9.376', 2006: '9.814', 2007: '10.213', 2008: '11.173', 2009: '11.281', 2010: '11.503', 2011: '11.196', 2012: '11.253', 2013: '10.689', 2014: '10.773', 2015: '10.427', 2016: '10.246', 2017: '10.339', 2018: '10.031'}
deklice_rojstva = {2005: '8.823', 2006: '9.215', 2007: '9.702', 2008: '10.693', 2009: '10.482', 2010: '10.793', 2011: '10.650', 2012: '10.536', 2013: '10.186', 2014: '10.084', 2015: '9.853', 2016: '9.837', 2017: '9.608', 2018: '9.298'}

moski = {'2005': ['UMRLI: 9.413', 'POVPREČNA_STAROST_UMRLIH: 68,9', 'UMRLI_DOJENČKI: 41'], '2006': ['UMRLI: 9.270', 'POVPREČNA_STAROST_UMRLIH: 68,5', 'UMRLI_DOJENČKI: 32'], '2007': ['UMRLI: 9.473', 'POVPREČNA_STAROST_UMRLIH: 69,1', 'UMRLI_DOJENČKI: 27'], '2008': ['UMRLI: 9.174', 'POVPREČNA_STAROST_UMRLIH: 69,9', 'UMRLI_DOJENČKI: 30'], '2009': ['UMRLI: 9.293', 'POVPREČNA_STAROST_UMRLIH: 70,1', 'UMRLI_DOJENČKI: 25'], '2010': ['UMRLI: 9.292', 'POVPREČNA_STAROST_UMRLIH: 70,7', 'UMRLI_DOJENČKI: 24'], '2011': ['UMRLI: 9.235', 'POVPREČNA_STAROST_UMRLIH: 71,2', 'UMRLI_DOJENČKI: 41'], '2012': ['UMRLI: 9.412', 'POVPREČNA_STAROST_UMRLIH: 71,8', 'UMRLI_DOJENČKI: 18'], '2013': ['UMRLI: 9.555', 'POVPREČNA_STAROST_UMRLIH: 71,9', 'UMRLI_DOJENČKI: 32'], '2014': ['UMRLI: 9.208', 'POVPREČNA_STAROST_UMRLIH: 72,7', 'UMRLI_DOJENČKI: 19'], '2015': ['UMRLI: 9.739', 'POVPREČNA_STAROST_UMRLIH: 72,8', 'UMRLI_DOJENČKI: 18'], '2016': ['UMRLI: 9.673', 'POVPREČNA_STAROST_UMRLIH: 73,0', 'UMRLI_DOJENČKI: 20'], '2017': ['UMRLI: 10.136', 'POVPREČNA_STAROST_UMRLIH: 74,0', 'UMRLI_DOJENČKI: 21'], '2018': ['UMRLI: 10.113', 'POVPREČNA_STAROST_UMRLIH: 74,1', 'UMRLI_DOJENČKI: 22']}
zenske = {'2005': ['UMRLI: 9.412', 'POVPREČNA_STAROST_UMRLIH: 77,8', 'UMRLI_DOJENČKI: 34'], '2006': ['UMRLI: 8.910', 'POVPREČNA_STAROST_UMRLIH: 78,1', 'UMRLI_DOJENČKI: 32'], '2007': ['UMRLI: 9.111', 'POVPREČNA_STAROST_UMRLIH: 78,2', 'UMRLI_DOJENČKI: 28'], '2008': ['UMRLI: 9.134', 'POVPREČNA_STAROST_UMRLIH: 78,8', 'UMRLI_DOJENČKI: 22'], '2009': ['UMRLI: 9.457', 'POVPREČNA_STAROST_UMRLIH: 79,1', 'UMRLI_DOJENČKI: 27'], '2010': ['UMRLI: 9.317', 'POVPREČNA_STAROST_UMRLIH: 79,3', 'UMRLI_DOJENČKI: 32'], '2011': ['UMRLI: 9.464', 'POVPREČNA_STAROST_UMRLIH: 79,7', 'UMRLI_DOJENČKI: 23'], '2012': ['UMRLI: 9.845', 'POVPREČNA_STAROST_UMRLIH: 80,0', 'UMRLI_DOJENČKI: 18'], '2013': ['UMRLI: 9.779', 'POVPREČNA_STAROST_UMRLIH: 80,3', 'UMRLI_DOJENČKI: 30'], '2014': ['UMRLI: 9.678', 'POVPREČNA_STAROST_UMRLIH: 80,9', 'UMRLI_DOJENČKI: 20'], '2015': ['UMRLI: 10.095', 'POVPREČNA_STAROST_UMRLIH: 81,0', 'UMRLI_DOJENČKI: 15'], '2016': ['UMRLI: 10.016', 'POVPREČNA_STAROST_UMRLIH: 81,4', 'UMRLI_DOJENČKI: 21'], '2017': ['UMRLI: 10.373', 'POVPREČNA_STAROST_UMRLIH: 81,4', 'UMRLI_DOJENČKI: 21'], '2018': ['UMRLI: 10.372', 'POVPREČNA_STAROST_UMRLIH: 81,6', 'UMRLI_DOJENČKI: 11']}
    
x_os = list()
umrli_z_1 = list()
for kljuc, vrednost in zenske.items():
    x_os.append(kljuc)
    
    umrli_z_1.append(vrednost[0])
    umrli_z = []
    for i in umrli_z_1:
        podatek = str(i)
        l = i.split(':')[1]
        st_l = float(l)
        umrli_z.append(st_l)

umrli_m_1 = list()
for kljuc,vrednost in moski.items():
    
    umrli_m_1.append(vrednost[0])
    umrli_m = []
    for i in umrli_m_1:
        podatek = str(i)
        l = i.split(':')[1]
        st_l = float(l)
        umrli_m.append(st_l)

tabela_prirastkov = list()
kljuc = 2005
for index in range(len(x_os)):
    st_umrlih = (umrli_m[index] +  umrli_z[index]) / 1000
    st_rojstev = (float(decki_rojstva[kljuc]) + float(deklice_rojstva[kljuc])) / 1000
    kljuc += 1
    tabela_prirastkov.append(round(st_rojstev - st_umrlih, 3))

i = -1
for leto in range(2005, 2019):
    i += 1
    if '-' in str(tabela_prirastkov[i]):
        print('V letu {} je bil naravni prirastek {}‰, kar pomeni, da je bilo več umrlih kot rojenih v tem letu.'.format(str(leto), tabela_prirastkov[i]))
    elif str(tabela_prirastkov[i]) == '0.0':
        print('V letu {} je bil naravni prirastek {}‰, kar pomeni, da je bilo enako število umrlih kot rojenih v tem letu.'.format(str(leto), tabela_prirastkov[i]))
    else: print('V letu {} je bil naravni prirastek {}‰, kar pomeni, da je bilo več rojenih kot umrlih v tem letu.'.format(str(leto), tabela_prirastkov[i]))
 
    
    
    
    